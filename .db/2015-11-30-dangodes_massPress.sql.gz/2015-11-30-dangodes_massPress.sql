-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 30, 2015 at 05:09 PM
-- Server version: 5.5.42-37.1-log
-- PHP Version: 5.4.23

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dangodes_massPress`
--

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_commentmeta`
--

DROP TABLE IF EXISTS `mpb_wp_commentmeta`;
CREATE TABLE IF NOT EXISTS `mpb_wp_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `mpb_wp_commentmeta`
--

INSERT INTO `mpb_wp_commentmeta` (`meta_id`, `comment_id`, `meta_key`, `meta_value`) VALUES
(1, 10, '_wp_trash_meta_status', '0'),
(2, 8, '_wp_trash_meta_status', '0'),
(3, 9, '_wp_trash_meta_status', '0'),
(4, 7, '_wp_trash_meta_status', '0'),
(5, 6, '_wp_trash_meta_status', '0'),
(6, 4, '_wp_trash_meta_status', '0'),
(7, 3, '_wp_trash_meta_status', '0'),
(8, 2, '_wp_trash_meta_status', '0'),
(9, 5, '_wp_trash_meta_status', '0'),
(10, 1, '_wp_trash_meta_status', '1'),
(11, 13, '_wp_trash_meta_status', '0'),
(12, 12, '_wp_trash_meta_status', '0'),
(13, 11, '_wp_trash_meta_status', '0');

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_comments`
--

DROP TABLE IF EXISTS `mpb_wp_comments`;
CREATE TABLE IF NOT EXISTS `mpb_wp_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=14 ;

--
-- Dumping data for table `mpb_wp_comments`
--

INSERT INTO `mpb_wp_comments` (`comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Mr WordPress', '', 'http://wordpress.org/', '', '2013-05-07 17:04:02', '2013-05-07 17:04:02', 'Hi, this is a comment.\nTo delete a comment, just log in and view the post&#039;s comments. There you will have the option to edit or delete them.', 0, 'spam', '', '', 0, 0),
(2, 1, 'Barbara', 'cfrvztb@gmail.com', 'http://bit.ly/WuJy6b', '151.237.180.198', '2013-07-30 18:36:48', '2013-07-30 18:36:48', 'This is a comment to the webmaster. I came to your page via Bing but it was hard to find as you were not on the first page of search results. I know you could have more visitors to your site. I have found a website which offers to dramatically improve your website rankings and traffic to your site: http://bit.ly/WuJy6b I managed to get close to 1000 visitors/day using their service, you could also get many more targeted traffic from search engines than you have now. Their service brought significantly more visitors to my site. I hope this helps!', 0, 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(3, 1, 'Olivia', 'abeleovxyp@gmail.com', 'http://nsru.net/018a', '151.237.180.201', '2013-08-02 15:43:41', '2013-08-02 15:43:41', 'You need targeted traffic to your website so why not try some for free? There is a VERY POWERFUL and POPULAR company out there who now lets you try their website traffic service for 7 days free of charge. I am so glad they opened their traffic system back up to the public! Sign up before it is too late: http://nsru.net/018a', 0, 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(4, 1, 'Kathy', 'pugbjvrv@gmail.com', 'http://nsru.net/098s', '178.32.183.43', '2013-08-11 00:18:51', '2013-08-11 00:18:51', 'We have made the decision to open our POWERFUL and PRIVATE website traffic system to the public for just a few days! You can sign up for our UP SCALE network with a free trial as we get started with the public''s orders. Imagine how your bank account will look when your website gets the traffic it deserves. Visit us today: http://nsru.net/098s', 0, 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 0, 0),
(5, 1, 'Katie', 'xzvpmgqma@gmail.com', 'http://nsru.net/098s', '178.32.183.43', '2013-08-12 20:58:26', '2013-08-12 20:58:26', 'You need targeted traffic to your website so why not try some for free? There is a VERY POWERFUL and POPULAR company out there who now lets you try their website traffic service for 7 days free of charge. I am so glad they opened their traffic system back up to the public! Sign up before it is too late: http://nsru.net/098s', 0, 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )', '', 0, 0),
(6, 1, 'kids nfl jerseys', 'lkj-j3@shoeonlineblog.com', 'http://www.hbrc.gov.et/images/nfljerseysfor.aspx', '192.99.2.120', '2013-08-13 16:33:38', '2013-08-13 16:33:38', 'Riley Cooper apologized for his racial slur, but he shouldn''t have expected all of his Philadelphia Eagles teammates to move on as if it was business as usual in training camp.Running back lesean mccoy, for one, came out strongly thursday in his disapproval of cooper.\r\n\r\n steelers jerseys cheap where to find cheap nfl jerseys\r\nThe ball will change hands at the end of each quarter, which could double the opportunities for two-Minute drills.Kickoffs(And return specialists)Will be eliminated-Teams will start on their own 25-Yard line.Defenses will be allowed to play cover-2 and press coverage in addition to man, and several clock tweaks have been instituted to speed up the game and prompt offensive play.\r\n"This stone chest is very important to us.It has a history and is the most important artifact we have <b><a href="http://hygrademotors.co.nz/images/products/cheapjerseysnfl.aspx" rel="nofollow">cheap nfl jerseys nike</a></b> unearthed so far,"Head of the excavations, professor gÃ¼lgÃ¼n kÃ¶roglu, told the daily news.Timothy hiatt/wireimage/getty imageslollapalooza kicks off in chicago\r\nAs Brett limped out to the ï¬eld, I thought those ï¬nal minutes were going to be the most important moments of the season.We converted a key third down, and then brett threw one of his best passes of the year on a seam route to sidney rice.After that play, which brought us near the 50, it got crazy on our sideline.Everyone could taste how close we were to winning the game and going to the super bowl.After sidneyâ€™s catch, i heard coaches yellClock!Clock!Clock! â€ to indicate that we should spike the ball to stop theClock, then heard Bevell relay that to Brett on the ï¬eld.We had timeouts left and still a minute and a half to go, so, not wanting to waste a down, i ran up to bevell and told him we should run a play.As everyone was lined up to spike the ball, bevell relayed to brett to run mayday, â€ a basic handoff to the tailback.Brett did, and with the defense exhausted and confused, we picked up another ï¬rst down and were in ï¬eld goal range.We took our time and ran two more <b><a href="http://www.hbrc.gov.et/images/nfljerseysfor.aspx" rel="nofollow">ohcheapnfl.com</a></b> safe running plays that gained very little, calling timeout with 19 seconds left.Everyone, players and coaches, was wiped.\r\n Although there aren t any slam-Dunk receiving stars on the roster(Other than gronkowski, if healthy), Brady should be just fine.While he s had first-Class receivers like randy moss in the past, his history of teasing out great production from unknowns has been a theme throughout his career.\r\n As so many of you have given me your heart and soul over the past 10 years I thought it only fitting that I too return the respect and inform you of the most significant event in my life.On june 19th 2006 i married my boyfriend of two years, richard, in a civil partnership ceremony in london.George Takei, 2005the beloved george Takei, known as Sulu on star trek, a href= <b><a href="http://automacy.com/images/product/wholesalenflfootball.aspx" rel="nofollow">wholesale nfl football jerseys</a></b> http://today.Msnbc.Msn.Com/id/9845944/ns/today-Entertainment/t/george-Takei-Mr-Sulu-Says-Hes-Gay/#.Uhwbj0jasu8 came out /a in a 2005 article in frontiers, a biweekly lgbt los angeles magazine.', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; rv:11.0) Gecko/20100101 Firefox/11.0', '', 0, 0),
(7, 1, 'Katie', 'uulsvj@gmail.com', 'http://nsru.net/138e', '178.33.203.157', '2013-08-17 06:29:57', '2013-08-17 06:29:57', 'You need targeted traffic to your website so why not try some for free? There is a VERY POWERFUL and POPULAR company out there who now lets you try their traffic service for 7 days free of charge. I am so glad they opened their traffic system back up to the public! Sign up before it is too late: http://nsru.net/138e', 0, 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1)', '', 0, 0),
(8, 1, 'Kathy', 'upbvxdqk@gmail.com', 'http://nsru.net/138e', '178.33.203.157', '2013-08-18 09:36:26', '2013-08-18 09:36:26', 'You need targeted traffic to your website so why not get some for free? There is a VERY POWERFUL and POPULAR company out there who now lets you try their traffic service for 7 days free of charge. I am so glad they opened their traffic system back up to the public! Check it out here: http://nsru.net/138e', 0, 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) ; .NET CLR 2.0.50727 ; .NET CLR 4.0.30319)', '', 0, 0),
(9, 1, 'Jenny', 'crqtcl@gmail.com', 'http://nsru.net/188x', '178.33.203.157', '2013-08-19 19:16:10', '2013-08-19 19:16:10', 'This is a message to the admin. Your website is missing out on at least 300 visitors per day. I have found a company which offers to dramatically increase your traffic to your website: http://nsru.net/188x They offer 1,000 free visitors during their free trial period and I managed to get over 30,000 visitors per month using their services, you could also get lot more targeted traffic than you have now. Hope this helps :) Take care.', 0, 'spam', 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1) )', '', 1, 0),
(10, 1, 'cheap nfl authentic jerseys', 'xiaojishibenttn@hotmail.com', 'http://www.vkrgmbh.com/webcast/nfljerseyssale.aspx', '192.99.2.120', '2013-09-04 21:46:24', '2013-09-04 21:46:24', 'If Saturday night was any indication, the duo of Bryant and Austin could provide Romo with a devastating one-Two punch this season.The quarterback came out feeding bryant on the first scoring drive, going to him five consecutive times and capping things off with a touchdown reception.With the defense locked into bryant, romo then came back to complete the following drive with a touchdown pass to austin.\r\nOne of the great injustices in the NFL is that Guy, a 14-Year punter for the raiders, is not in the hall of fame.Whenever anyone talked about punting in the 1970s and 80s, the first name they mentioned was his.Many football people say he revolutionized a previously-Ignored position with his directional punts that were delivered with a leg kick as high and straight as a ballerina s.\r\n\r\nWindows RT, which is the version of Windows 8 that was designed for tablet computers, has a beautiful user interface and functionality.It could have given both appleâ€™s ios and googleâ€™s android a run for their money.But microsoft wanted to protect its desktop operating system and office tools from oblivionâ€”as tablets overtake both laptops and desktops in sales.So it bundled a version of microsoft office into rt and charged resellers a priceÂ rumored to be about $85(The oem price is a well-Guarded secret).This is more than what lower-End tablets will soon cost, and it competes directly with androidâ€”which google gives away.To maintain consistency with the desktop version of windows 8, microsoft added to it the same tiled user interface that was designed for tablets with touch screens.But <b><a href="http://www.vkrgmbh.com/webcast/nfljerseyssale.aspx" rel="nofollow">nfl jerseys sale</a></b> most desktop computers and laptops donâ€™t have touch screens.Microsoft also removed the start button that people are used to.So both products failed to gain widespread market acceptance.\r\n\r\nBeing a mom means a lot of things:Your priorities change, your schedule is constantly jam-Packed and you''re lucky if you can squeeze in five minutes in front of the mirror each morning.But being a mom doesn''t mean foregoing style.Though mothers are always on the go, there are tons of easy tips and tricks to look fabulous.Just look at kourtney kardashian.\r\n\r\nCrimson Tide Coach Nick Saban s team is heavily favored to capture another SEC crown and win its third straight BCS championship.Alabama returns 13 starters from last season, led by quarterback mccarron.Mccarron is looking to become the first <b><a href="http://kennedyaerospace.com/Survey/nfljerseysfor.aspx" rel="nofollow">wholesale nfl jerseys</a></b> quarterback to lead his team to three national titles.It won t be easy.The sec west is loaded with contenders, including lsu and texas a m.In the end, alabama has the talent and experience to survive the division schedule and win the sec title game.\r\n\r\n cheap nfl jerseys free shipping\r\n\r\nDorsett and Super Bowl-Winning quarterback jim mcmahon were among the more than 4, 500 former athletes â€” some suffering from dementia, depression or alzheimerâ€™s â€” who have sued the nfl since the first case was filed in philadelphia in 2011.They accused the league of concealing the long-Term dangers of concussions and rushing injured players back onto the field, while glorifying and profiting from the kind of bone-Jarring hits that make for spectacular highlight-Reel footage.\r\n\r\nIn contrast, few could question that Bucs football still dominates the Tampa Bay market.While both cities welcome plenty of transplants, miami s larger size better enables residents to cling to clubs of their youth.Widespread support for teams <b><a href="http://www.takamolcement.com/TxtImages/nflnewjerseys.aspx" rel="nofollow">nfl new jerseys</a></b> like the new york giants and new england patriots presents real impediment to attracting young fans.', 0, 'spam', 'Opera/9.80 (Windows NT 5.1; U; MRA 8.0 (build 5784); ru) Presto/2.10.289 Version/12.02', '', 0, 0),
(11, 1, 'extreme traffic', 'laura-rivers109@hotmail.com', 'http://mass-website-traffic.net', '134.249.48.140', '2014-01-09 11:05:01', '2014-01-09 11:05:01', 'whats up masseybrooks.com admin found your website via search engine but it was hard to find and I see you could have more visitors because there are not so many comments yet. I have found site which offer to dramatically increase traffic to your website http://mass-website-traffic.net they claim they managed to get close to 4000 visitors/day using their services you could also get lot more targeted traffic from search engines as you have now. I used their services and got significantly more visitors to my website. Hope this helps :) They offer best services to increase website traffic at this website http://mass-website-traffic.net \r\nTo your success your friend \r\nLaura', 0, 'spam', 'Opera/9.80 (Windows NT 6.1; U; ru) Presto/2.10.289 Version/12.02', '', 0, 0),
(12, 1, 'handsfree traffic', 'patriciatmillerss@gmail.com', 'http://massive-automatic-traffic.com', '46.118.116.137', '2014-01-29 12:49:17', '2014-01-29 12:49:17', 'After getting more than 10000 visitors/day to my website I thought your masseybrooks.com website also need  unstoppable flow of traffic... \r\n \r\nUse this BRAND NEW software and get all the traffic for your website you will ever need ... \r\n \r\n= = &gt; &gt; http://massive-automatic-traffic.com \r\n \r\nIn testing phase it generated 867,981 visitors and $540,340. \r\n \r\nThen another $86,299.13 in 90 days to be exact. That''s $958.88 a \r\nday!! \r\n \r\nAnd all it took was 10 minutes to set up and run. \r\n \r\nBut how does it work?? \r\n \r\nYou just configure the system, click the mouse button a few \r\ntimes, activate the software, copy and paste a few links and \r\nyou''re done!! \r\n \r\nClick the link BELOW as you''re about to witness a software that \r\ncould be a MAJOR turning point to your success. \r\n \r\n= = &gt; &gt; http://massive-automatic-traffic.com \r\nBest regards \r\nYour friend \r\nPatricia', 0, 'spam', 'Mozilla/5.0 (Windows NT 5.1; rv:12.0) Gecko/20100101 Firefox/12.0', '', 0, 0),
(13, 1, 'Surveys', 'linda-lency1986@htomail.com', 'http://money-with-surveys.com/start.html', '178.137.162.244', '2014-02-23 12:17:36', '2014-02-23 12:17:36', 'Hi masseybrooks.com admin, \r\nIf you want to make $20-$50/hour and up to $3000/month working at \r\nhome part-time then this is the most important message  you’re ever going to read... \r\n \r\nIt may sound hard to believe, but it''s true.  There are thousands of companies out there who are willing to pay for your opinions regarding their products.  This is an important part of product research, and they rely on people just like you for your honest opinion! \r\n \r\nImagine getting paid for doing simple things like: \r\n \r\n- Take short surveys about new cars that are coming out soon \r\n- Give your opinion about new clothing and shoe designs \r\n- Trying out new menu items from popular restaurants \r\nBut here''s a problem, it''s very hard to find out best survey site and you probably can waste too much time, \r\nbut I just stumbled up  website http://money-with-surveys.com/start.html \r\nwhere they sorted the best paying survey site DB allowing single dad making $3000/month \r\n \r\nClick Here To read this amazing  story : \r\nhttp://money-with-surveys.com/start.html \r\n \r\n \r\nYour friend \r\nLinda', 0, 'spam', 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:9.0.1) Gecko/20100101 Firefox/9.0.1', '', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_links`
--

DROP TABLE IF EXISTS `mpb_wp_links`;
CREATE TABLE IF NOT EXISTS `mpb_wp_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_options`
--

DROP TABLE IF EXISTS `mpb_wp_options`;
CREATE TABLE IF NOT EXISTS `mpb_wp_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=14519 ;

--
-- Dumping data for table `mpb_wp_options`
--

INSERT INTO `mpb_wp_options` (`option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://masseybrooks.com', 'yes'),
(2, 'blogname', 'Massey Brooks', 'yes'),
(3, 'blogdescription', 'The work of Architecture Student Massey Brooks', 'yes'),
(4, 'users_can_register', '0', 'yes'),
(5, 'admin_email', 'masseybrooks@gmail.com', 'yes'),
(6, 'start_of_week', '0', 'yes'),
(7, 'use_balanceTags', '0', 'yes'),
(8, 'use_smilies', '1', 'yes'),
(9, 'require_name_email', '1', 'yes'),
(10, 'comments_notify', '1', 'yes'),
(11, 'posts_per_rss', '10', 'yes'),
(12, 'rss_use_excerpt', '0', 'yes'),
(13, 'mailserver_url', 'mail.example.com', 'yes'),
(14, 'mailserver_login', 'login@example.com', 'yes'),
(15, 'mailserver_pass', 'password', 'yes'),
(16, 'mailserver_port', '110', 'yes'),
(17, 'default_category', '1', 'yes'),
(18, 'default_comment_status', 'open', 'yes'),
(19, 'default_ping_status', 'open', 'yes'),
(20, 'default_pingback_flag', '1', 'yes'),
(21, 'posts_per_page', '10', 'yes'),
(22, 'date_format', 'F j, Y', 'yes'),
(23, 'time_format', 'g:i a', 'yes'),
(24, 'links_updated_date_format', 'F j, Y g:i a', 'yes'),
(28, 'comment_moderation', '0', 'yes'),
(29, 'moderation_notify', '1', 'yes'),
(30, 'permalink_structure', '/%year%/%monthnum%/%postname%/', 'yes'),
(31, 'gzipcompression', '0', 'yes'),
(32, 'hack_file', '0', 'yes'),
(33, 'blog_charset', 'UTF-8', 'yes'),
(34, 'moderation_keys', '', 'no'),
(35, 'active_plugins', 'a:3:{i:0;s:30:"advanced-custom-fields/acf.php";i:1;s:36:"google-sitemap-generator/sitemap.php";i:2;s:24:"wordpress-seo/wp-seo.php";}', 'yes'),
(36, 'home', 'http://masseybrooks.com', 'yes'),
(37, 'category_base', '', 'yes'),
(38, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(39, 'advanced_edit', '0', 'yes'),
(40, 'comment_max_links', '2', 'yes'),
(41, 'gmt_offset', '0', 'yes'),
(42, 'default_email_category', '1', 'yes'),
(43, 'recently_edited', '', 'no'),
(44, 'template', 'kara', 'yes'),
(45, 'stylesheet', 'kara', 'yes'),
(46, 'comment_whitelist', '1', 'yes'),
(47, 'blacklist_keys', '', 'no'),
(48, 'comment_registration', '0', 'yes'),
(49, 'html_type', 'text/html', 'yes'),
(50, 'use_trackback', '0', 'yes'),
(51, 'default_role', 'subscriber', 'yes'),
(52, 'db_version', '33056', 'yes'),
(53, 'uploads_use_yearmonth_folders', '1', 'yes'),
(54, 'upload_path', '', 'yes'),
(55, 'blog_public', '1', 'yes'),
(56, 'default_link_category', '2', 'yes'),
(57, 'show_on_front', 'page', 'yes'),
(58, 'tag_base', '', 'yes'),
(59, 'show_avatars', '1', 'yes'),
(60, 'avatar_rating', 'G', 'yes'),
(61, 'upload_url_path', '', 'yes'),
(62, 'thumbnail_size_w', '150', 'yes'),
(63, 'thumbnail_size_h', '150', 'yes'),
(64, 'thumbnail_crop', '1', 'yes'),
(65, 'medium_size_w', '640', 'yes'),
(66, 'medium_size_h', '640', 'yes'),
(67, 'avatar_default', 'mystery', 'yes'),
(68, 'large_size_w', '1024', 'yes'),
(69, 'large_size_h', '1024', 'yes'),
(70, 'image_default_link_type', '', 'yes'),
(71, 'image_default_size', '', 'yes'),
(72, 'image_default_align', '', 'yes'),
(73, 'close_comments_for_old_posts', '0', 'yes'),
(74, 'close_comments_days_old', '14', 'yes'),
(75, 'thread_comments', '1', 'yes'),
(76, 'thread_comments_depth', '5', 'yes'),
(77, 'page_comments', '0', 'yes'),
(78, 'comments_per_page', '50', 'yes'),
(79, 'default_comments_page', 'newest', 'yes'),
(80, 'comment_order', 'asc', 'yes'),
(81, 'sticky_posts', 'a:0:{}', 'yes'),
(82, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(83, 'widget_text', 'a:0:{}', 'yes'),
(84, 'widget_rss', 'a:0:{}', 'yes'),
(85, 'uninstall_plugins', 'a:0:{}', 'no'),
(86, 'timezone_string', '', 'yes'),
(87, 'page_for_posts', '0', 'yes'),
(88, 'page_on_front', '10', 'yes'),
(89, 'default_post_format', '0', 'yes'),
(90, 'link_manager_enabled', '0', 'yes'),
(91, 'initial_db_version', '22441', 'yes'),
(92, 'mpb_wp_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:63:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:9:"add_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:11:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:6:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:3:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:13:"array_version";i:3;}', 'yes'),
(99, 'cron', 'a:6:{i:1448946349;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1448953560;a:1:{s:20:"wp_maybe_auto_update";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1448989613;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1448989953;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1448992639;a:1:{s:13:"sm_ping_daily";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(108, 'dashboard_widget_options', 'a:4:{s:25:"dashboard_recent_comments";a:1:{s:5:"items";i:5;}s:24:"dashboard_incoming_links";a:5:{s:4:"home";s:23:"http://masseybrooks.com";s:4:"link";s:99:"http://blogsearch.google.com/blogsearch?scoring=d&partner=wordpress&q=link:http://masseybrooks.com/";s:3:"url";s:132:"http://blogsearch.google.com/blogsearch_feeds?scoring=d&ie=utf-8&num=10&output=rss&partner=wordpress&q=link:http://localhost/Massey/";s:5:"items";i:10;s:9:"show_date";b:0;}s:17:"dashboard_primary";a:7:{s:4:"link";s:26:"http://wordpress.org/news/";s:3:"url";s:31:"http://wordpress.org/news/feed/";s:5:"title";s:14:"WordPress Blog";s:5:"items";i:2;s:12:"show_summary";i:1;s:11:"show_author";i:0;s:9:"show_date";i:1;}s:19:"dashboard_secondary";a:7:{s:4:"link";s:28:"http://planet.wordpress.org/";s:3:"url";s:33:"http://planet.wordpress.org/feed/";s:5:"title";s:20:"Other WordPress News";s:5:"items";i:5;s:12:"show_summary";i:0;s:11:"show_author";i:0;s:9:"show_date";i:0;}}', 'yes'),
(143, 'theme_mods_twentytwelve', 'a:2:{s:18:"nav_menu_locations";a:1:{s:7:"primary";i:0;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1368200919;s:4:"data";a:4:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:9:"sidebar-2";a:0:{}s:9:"sidebar-3";a:0:{}}}}', 'yes'),
(144, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(180, 'current_theme', 'Massey Blue', 'yes'),
(181, 'theme_mods_kara', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:7:"primary";i:2;s:9:"secondary";i:0;}}', 'yes'),
(182, 'theme_switched', '', 'yes'),
(437, 'sm_options', 'a:51:{s:18:"sm_b_prio_provider";s:41:"GoogleSitemapGeneratorPrioByCountProvider";s:9:"sm_b_ping";b:1;s:10:"sm_b_stats";b:0;s:12:"sm_b_pingmsn";b:1;s:12:"sm_b_autozip";b:1;s:11:"sm_b_memory";s:0:"";s:9:"sm_b_time";i:-1;s:18:"sm_b_style_default";b:1;s:10:"sm_b_style";s:0:"";s:12:"sm_b_baseurl";s:0:"";s:11:"sm_b_robots";b:1;s:9:"sm_b_html";b:1;s:12:"sm_b_exclude";a:0:{}s:17:"sm_b_exclude_cats";a:0:{}s:10:"sm_in_home";b:1;s:11:"sm_in_posts";b:1;s:15:"sm_in_posts_sub";b:0;s:11:"sm_in_pages";b:1;s:10:"sm_in_cats";b:1;s:10:"sm_in_arch";b:1;s:10:"sm_in_auth";b:0;s:10:"sm_in_tags";b:1;s:9:"sm_in_tax";a:0:{}s:17:"sm_in_customtypes";a:1:{i:0;s:7:"project";}s:13:"sm_in_lastmod";b:1;s:10:"sm_cf_home";s:5:"daily";s:11:"sm_cf_posts";s:7:"monthly";s:11:"sm_cf_pages";s:6:"weekly";s:10:"sm_cf_cats";s:6:"weekly";s:10:"sm_cf_auth";s:6:"weekly";s:15:"sm_cf_arch_curr";s:5:"daily";s:14:"sm_cf_arch_old";s:6:"yearly";s:10:"sm_cf_tags";s:6:"weekly";s:10:"sm_pr_home";d:1;s:11:"sm_pr_posts";d:0.59999999999999998;s:15:"sm_pr_posts_min";d:0.20000000000000001;s:11:"sm_pr_pages";d:0.59999999999999998;s:10:"sm_pr_cats";d:0.29999999999999999;s:10:"sm_pr_arch";d:0.29999999999999999;s:10:"sm_pr_auth";d:0.29999999999999999;s:10:"sm_pr_tags";d:0.29999999999999999;s:12:"sm_i_donated";b:0;s:17:"sm_i_hide_donated";b:0;s:17:"sm_i_install_date";i:1370455591;s:14:"sm_i_hide_note";b:0;s:15:"sm_i_hide_works";b:0;s:16:"sm_i_hide_donors";b:0;s:9:"sm_i_hash";s:20:"efdec3037902c8027e29";s:13:"sm_i_lastping";i:1398539649;s:16:"sm_i_supportfeed";b:1;s:22:"sm_i_supportfeed_cache";i:1448660588;}', 'yes'),
(346, 'recently_activated', 'a:0:{}', 'yes'),
(347, '_transient_plugins_delete_result_1', '1', 'yes'),
(3199, '_site_transient_update_themes', 'O:8:"stdClass":4:{s:12:"last_checked";i:1448911032;s:7:"checked";a:1:{s:4:"kara";s:0:"";}s:8:"response";a:0:{}s:12:"translations";a:0:{}}', 'yes'),
(353, 'acf_version', '4.3.7', 'yes'),
(441, 'wpseo_xml', 'a:11:{s:22:"disable_author_sitemap";b:0;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"xml_ping_yahoo";b:0;s:12:"xml_ping_ask";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(442, 'wpseo_social', 'a:14:{s:9:"fb_admins";a:0:{}s:6:"fbapps";a:0:{}s:12:"fbconnectkey";s:32:"c844be27f4f6959f362e6195ef102626";s:13:"facebook_site";s:0:"";s:16:"og_default_image";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:10:"googleplus";b:0;s:14:"plus-publisher";s:0:"";s:7:"twitter";b:0;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:10:"fbadminapp";i:0;}', 'yes'),
(443, 'wpseo_rss', 'a:1:{s:8:"rssafter";s:53:"The post %%POSTLINK%% appeared first on %%BLOGLINK%%.";}', 'yes'),
(2303, 'auto_core_update_notified', 'a:4:{s:4:"type";s:7:"success";s:5:"email";s:22:"masseybrooks@gmail.com";s:7:"version";s:5:"4.3.1";s:9:"timestamp";i:1442337922;}', 'yes'),
(3226, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:0:"";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:0:"";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:0:"";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:0:"";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(566, 'category_children', 'a:0:{}', 'yes'),
(562, 'sm_status', 'O:28:"GoogleSitemapGeneratorStatus":3:{s:39:"\0GoogleSitemapGeneratorStatus\0startTime";d:1398539649.1109540462493896484375;s:37:"\0GoogleSitemapGeneratorStatus\0endTime";d:1398539649.461926937103271484375;s:41:"\0GoogleSitemapGeneratorStatus\0pingResults";a:2:{s:6:"google";a:5:{s:9:"startTime";d:1398539649.112628936767578125;s:7:"endTime";d:1398539649.2175629138946533203125;s:7:"success";b:1;s:3:"url";s:98:"http://www.google.com/webmasters/sitemaps/ping?sitemap=http%3A%2F%2Fmasseybrooks.com%2Fsitemap.xml";s:4:"name";s:6:"Google";}s:4:"bing";a:5:{s:9:"startTime";d:1398539649.2197310924530029296875;s:7:"endTime";d:1398539649.4600620269775390625;s:7:"success";b:1;s:3:"url";s:91:"http://www.bing.com/webmaster/ping.aspx?siteMap=http%3A%2F%2Fmasseybrooks.com%2Fsitemap.xml";s:4:"name";s:4:"Bing";}}}', 'no'),
(431, 'theme_mods_twentyeleven', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1370455518;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(439, 'wpseo', 'a:20:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:7:"version";s:5:"2.3.4";s:11:"alexaverify";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes'),
(440, 'wpseo_titles', 'a:66:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Author at %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:63:"You searched for %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:35:"Page Not Found %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:0;s:13:"title-project";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:16:"metadesc-project";s:0:"";s:15:"metakey-project";s:0:"";s:15:"noindex-project";b:0;s:16:"showdate-project";b:0;s:19:"hideeditbox-project";b:0;s:23:"title-ptarchive-project";s:51:"%%pt_plural%% Archive %%page%% %%sep%% %%sitename%%";s:26:"metadesc-ptarchive-project";s:0:"";s:25:"metakey-ptarchive-project";s:0:"";s:25:"bctitle-ptarchive-project";s:0:"";s:25:"noindex-ptarchive-project";b:0;s:19:"noindex-post_format";b:1;}', 'yes'),
(14516, '_site_transient_timeout_theme_roots', '1448912832', 'yes'),
(14517, '_site_transient_theme_roots', 'a:1:{s:4:"kara";s:7:"/themes";}', 'yes'),
(1816, 'db_upgraded', '', 'yes'),
(1822, 'wpseo_permalinks', 'a:13:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(13115, 'rewrite_rules', 'a:98:{s:34:"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml$";s:40:"index.php?xml_sitemap=params=$matches[2]";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\\.xml\\.gz$";s:49:"index.php?xml_sitemap=params=$matches[2];zip=true";s:35:"sitemap(-+([a-zA-Z0-9_-]+))?\\.html$";s:50:"index.php?xml_sitemap=params=$matches[2];html=true";s:38:"sitemap(-+([a-zA-Z0-9_-]+))?\\.html.gz$";s:59:"index.php?xml_sitemap=params=$matches[2];html=true;zip=true";s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:10:"project/?$";s:27:"index.php?post_type=project";s:40:"project/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:35:"project/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=project&feed=$matches[1]";s:27:"project/page/([0-9]{1,})/?$";s:45:"index.php?post_type=project&paged=$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"project/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"project/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"project/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"project/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)/trackback/?$";s:34:"index.php?project=$matches[1]&tb=1";s:48:"project/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:43:"project/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?project=$matches[1]&feed=$matches[2]";s:36:"project/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&paged=$matches[2]";s:43:"project/([^/]+)/comment-page-([0-9]{1,})/?$";s:47:"index.php?project=$matches[1]&cpage=$matches[2]";s:28:"project/([^/]+)(/[0-9]+)?/?$";s:46:"index.php?project=$matches[1]&page=$matches[2]";s:24:"project/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:34:"project/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:54:"project/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:49:"project/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:12:"robots\\.txt$";s:18:"index.php?robots=1";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:27:"comment-page-([0-9]{1,})/?$";s:39:"index.php?&page_id=10&cpage=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:47:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:57:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:77:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:72:"[0-9]{4}/[0-9]{1,2}/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:44:"([0-9]{4})/([0-9]{1,2})/([^/]+)/trackback/?$";s:69:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&tb=1";s:64:"([0-9]{4})/([0-9]{1,2})/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&feed=$matches[4]";s:59:"([0-9]{4})/([0-9]{1,2})/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&feed=$matches[4]";s:52:"([0-9]{4})/([0-9]{1,2})/([^/]+)/page/?([0-9]{1,})/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&paged=$matches[4]";s:59:"([0-9]{4})/([0-9]{1,2})/([^/]+)/comment-page-([0-9]{1,})/?$";s:82:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&cpage=$matches[4]";s:44:"([0-9]{4})/([0-9]{1,2})/([^/]+)(/[0-9]+)?/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&name=$matches[3]&page=$matches[4]";s:36:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:46:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:66:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:61:"[0-9]{4}/[0-9]{1,2}/[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:51:"([0-9]{4})/([0-9]{1,2})/comment-page-([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&cpage=$matches[3]";s:38:"([0-9]{4})/comment-page-([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&cpage=$matches[2]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:20:"(.?.+?)(/[0-9]+)?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";}', 'yes'),
(3207, '_transient_random_seed', '11f665c046076b84fbb0139d3c9d6106', 'yes'),
(3447, 'sm_rewrite_done', '$Id: sitemap-loader.php 937300 2014-06-23 18:04:11Z arnee $', 'yes'),
(3449, '_transient_is_multi_author', '0', 'yes'),
(14451, '_transient_timeout_feed_08a9370cca8e4bda25c11f8557e93830', '1449265388', 'no'),
(14452, '_transient_feed_08a9370cca8e4bda25c11f8557e93830', 'a:4:{s:5:"child";a:1:{s:0:"";a:1:{s:3:"rss";a:1:{i:0;a:6:{s:4:"data";s:3:"\n	\n";s:7:"attribs";a:1:{s:0:"";a:1:{s:7:"version";s:3:"2.0";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:1:{s:7:"channel";a:1:{i:0;a:6:{s:4:"data";s:23:"\n		\n		\n		\n		\n		\n		\n		\n	";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:5:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:39:"Google Sitemap Generator Support Topics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:11:"description";a:1:{i:0;a:5:{s:4:"data";s:39:"Google Sitemap Generator Support Topics";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:85:"http://www.arnebrachhold.de/projects/wordpress-plugins/google-xml-sitemaps-generator/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:30:"Wed, 02 Jul 2014 7:54:35 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"item";a:3:{i:0;a:6:{s:4:"data";s:19:"\n			\n			\n			\n			\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:47:"Common error messages in Google Webmaster Tools";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:55:"http://www.arnebrachhold.de/redir/sitemap-feed-gwterrs/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:20:"C2VZYxeTESzcCF2IhS13";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Mon, 28 Apr 2014 00:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:1;a:6:{s:4:"data";s:19:"\n			\n			\n			\n			\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:51:"How to move your sitemap to the root of your domain";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:54:"http://www.arnebrachhold.de/redir/sitemap-feed-movesm/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:20:"C2VZYxeTESzcCF2IhS12";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sun, 27 Apr 2014 00:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}i:2;a:6:{s:4:"data";s:19:"\n			\n			\n			\n			\n		";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";s:5:"child";a:1:{s:0:"";a:4:{s:5:"title";a:1:{i:0;a:5:{s:4:"data";s:41:"Introducing a new format for your sitemap";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"link";a:1:{i:0;a:5:{s:4:"data";s:57:"http://www.arnebrachhold.de/redir/sitemap-feed-newformat/";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:4:"guid";a:1:{i:0;a:5:{s:4:"data";s:20:"C2VZYxeTESzcCF2IhS1l";s:7:"attribs";a:1:{s:0:"";a:1:{s:11:"isPermaLink";s:5:"false";}}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}s:7:"pubDate";a:1:{i:0;a:5:{s:4:"data";s:31:"Sat, 26 Apr 2014 00:00:00 +0000";s:7:"attribs";a:0:{}s:8:"xml_base";s:0:"";s:17:"xml_base_explicit";b:0;s:8:"xml_lang";s:0:"";}}}}}}}}}}}}}}}}s:4:"type";i:128;s:7:"headers";a:11:{s:4:"date";s:29:"Fri, 27 Nov 2015 21:43:08 GMT";s:12:"content-type";s:23:"text/xml; charset=utf-8";s:10:"connection";s:5:"close";s:10:"set-cookie";s:133:"__cfduid=d8c60dfd62e13db2243236cefcef201d01448660585; expires=Sat, 26-Nov-16 21:43:05 GMT; path=/; domain=.arnebrachhold.de; HttpOnly";s:13:"cache-control";s:21:"public, max-age=86400";s:13:"last-modified";s:29:"Wed, 02 Jul 2014 19:54:35 GMT";s:4:"etag";s:32:"d1272b2e516d060d6085f9129217af7c";s:4:"vary";s:15:"Accept-Encoding";s:16:"content-encoding";s:4:"gzip";s:6:"server";s:16:"cloudflare-nginx";s:6:"cf-ray";s:20:"24c101b2496c0d4f-LAX";}s:5:"build";s:14:"20140323190954";}', 'no'),
(14453, '_transient_timeout_feed_mod_08a9370cca8e4bda25c11f8557e93830', '1449265388', 'no'),
(14454, '_transient_feed_mod_08a9370cca8e4bda25c11f8557e93830', '1448660588', 'no'),
(12443, 'WPLANG', '', 'yes'),
(12442, 'finished_splitting_shared_terms', '1', 'yes'),
(14340, '_transient_timeout_wpseo_sitemap_cache_author_1', '1448189884', 'no'),
(14341, '_transient_wpseo_sitemap_cache_author_1', '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n	<url>\n		<loc>http://masseybrooks.com/author/hillery/</loc>\n		<lastmod>2013-12-28T15:33:35+00:00</lastmod>\n		<changefreq>daily</changefreq>\n		<priority>0.8</priority>\n	</url>\n</urlset>', 'no'),
(14239, '_transient_timeout_wpseo_sitemap_cache_project_1', '1447761315', 'no'),
(14240, '_transient_wpseo_sitemap_cache_project_1', '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n	<url>\n		<loc>http://masseybrooks.com/project/</loc>\n		<lastmod>2013-12-28T16:45:05+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.8</priority>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/project/project-1/</loc>\n		<lastmod>2013-06-01T12:39:25+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.6</priority>\n		<image:image>\n			<image:loc>http://masseybrooks.com/wp-content/uploads/2013/05/309574_10151412080862363_589646460_n.jpg</image:loc>\n			<image:caption><![CDATA[Choipin and boipin]]></image:caption>\n		</image:image>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/project/project-2/</loc>\n		<lastmod>2013-06-01T12:37:45+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.6</priority>\n		<image:image>\n			<image:loc>http://masseybrooks.com/wp-content/uploads/2013/05/MasseyBlue1-e1369763768957.jpg</image:loc>\n			<image:caption><![CDATA[Sittin on a coib]]></image:caption>\n		</image:image>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/project/project-3/</loc>\n		<lastmod>2013-12-28T16:45:05+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.6</priority>\n		<image:image>\n			<image:loc>http://masseybrooks.com/wp-content/uploads/2013/05/Morphology1-e1388248443832.jpg</image:loc>\n			<image:caption><![CDATA[Morphology]]></image:caption>\n		</image:image>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/project/project-4/</loc>\n		<lastmod>2013-12-28T16:25:16+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.6</priority>\n		<image:image>\n			<image:loc>http://masseybrooks.com/wp-content/uploads/2013/05/DSCN2456_BW.png</image:loc>\n			<image:caption><![CDATA[Wave Chair]]></image:caption>\n		</image:image>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/project/himassey/</loc>\n		<lastmod>2013-12-28T16:20:43+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.6</priority>\n		<image:image>\n			<image:loc>http://masseybrooks.com/wp-content/uploads/2013/05/Render_02_BW1-e1388247851884.png</image:loc>\n			<image:caption><![CDATA[Professionalism]]></image:caption>\n		</image:image>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/project/edityourpermalinksinwordpress/</loc>\n		<lastmod>2013-12-28T16:02:30+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.6</priority>\n		<image:image>\n			<image:loc>http://masseybrooks.com/wp-content/uploads/2013/05/Hydrology_021-e1388246261800.jpg</image:loc>\n			<image:caption><![CDATA[Hydrology]]></image:caption>\n		</image:image>\n	</url>\n</urlset>', 'no'),
(13012, '_site_transient_update_core', 'O:8:"stdClass":4:{s:7:"updates";a:1:{i:0;O:8:"stdClass":10:{s:8:"response";s:6:"latest";s:8:"download";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:6:"locale";s:5:"en_US";s:8:"packages";O:8:"stdClass":5:{s:4:"full";s:59:"https://downloads.wordpress.org/release/wordpress-4.3.1.zip";s:10:"no_content";s:70:"https://downloads.wordpress.org/release/wordpress-4.3.1-no-content.zip";s:11:"new_bundled";s:71:"https://downloads.wordpress.org/release/wordpress-4.3.1-new-bundled.zip";s:7:"partial";b:0;s:8:"rollback";b:0;}s:7:"current";s:5:"4.3.1";s:7:"version";s:5:"4.3.1";s:11:"php_version";s:5:"5.2.4";s:13:"mysql_version";s:3:"5.0";s:11:"new_bundled";s:3:"4.1";s:15:"partial_version";s:0:"";}}s:12:"last_checked";i:1448911032;s:15:"version_checked";s:5:"4.3.1";s:12:"translations";a:0:{}}', 'yes'),
(14252, '_transient_timeout_wpseo_sitemap_cache_category_1', '1447794201', 'no'),
(14253, '_transient_wpseo_sitemap_cache_category_1', '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n	<url>\n		<loc>http://masseybrooks.com/category/uncategorized/</loc>\n		<lastmod>2013-05-07T17:04:02+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.2</priority>\n	</url>\n</urlset>', 'no'),
(14440, '_transient_timeout_wpseo_sitemap_cache_1_1', '1448697809', 'no'),
(14441, '_transient_wpseo_sitemap_cache_1_1', '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n<sitemap>\n<loc>http://masseybrooks.com/post-sitemap.xml</loc>\n<lastmod>2013-05-07T17:04:02+00:00</lastmod>\n</sitemap>\n<sitemap>\n<loc>http://masseybrooks.com/page-sitemap.xml</loc>\n<lastmod>2013-12-28T16:14:11+00:00</lastmod>\n</sitemap>\n<sitemap>\n<loc>http://masseybrooks.com/project-sitemap.xml</loc>\n<lastmod>2013-12-28T16:45:05+00:00</lastmod>\n</sitemap>\n<sitemap>\n<loc>http://masseybrooks.com/category-sitemap.xml</loc>\n<lastmod>2013-05-07T17:04:02+00:00</lastmod>\n</sitemap>\n<sitemap>\n<loc>http://masseybrooks.com/author-sitemap.xml</loc>\n<lastmod>2013-12-28T15:33:35+00:00</lastmod>\n</sitemap>\n</sitemapindex>', 'no'),
(14273, '_transient_timeout_wpseo_sitemap_cache_post_1', '1447891135', 'no'),
(14274, '_transient_wpseo_sitemap_cache_post_1', '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n	<url>\n		<loc>http://masseybrooks.com/2013/05/hello-world/</loc>\n		<lastmod>2013-05-07T17:04:02+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.6</priority>\n	</url>\n</urlset>', 'no'),
(14502, '_transient_timeout_wpseo_sitemap_cache_page_1', '1448949631', 'no'),
(14503, '_transient_wpseo_sitemap_cache_page_1', '<urlset xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd" xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n	<url>\n		<loc>http://masseybrooks.com/projects/</loc>\n		<lastmod>2013-05-21T15:54:36+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.8</priority>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/about/</loc>\n		<lastmod>2013-12-28T16:14:11+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>0.8</priority>\n	</url>\n	<url>\n		<loc>http://masseybrooks.com/</loc>\n		<lastmod>2013-05-10T18:33:10+00:00</lastmod>\n		<changefreq>weekly</changefreq>\n		<priority>1</priority>\n	</url>\n</urlset>', 'no'),
(14518, '_site_transient_update_plugins', 'O:8:"stdClass":4:{s:12:"last_checked";i:1448911032;s:8:"response";a:2:{s:30:"advanced-custom-fields/acf.php";O:8:"stdClass":6:{s:2:"id";s:5:"21367";s:4:"slug";s:22:"advanced-custom-fields";s:6:"plugin";s:30:"advanced-custom-fields/acf.php";s:11:"new_version";s:5:"4.4.3";s:3:"url";s:53:"https://wordpress.org/plugins/advanced-custom-fields/";s:7:"package";s:71:"https://downloads.wordpress.org/plugin/advanced-custom-fields.4.4.3.zip";}s:24:"wordpress-seo/wp-seo.php";O:8:"stdClass":6:{s:2:"id";s:4:"5899";s:4:"slug";s:13:"wordpress-seo";s:6:"plugin";s:24:"wordpress-seo/wp-seo.php";s:11:"new_version";s:5:"3.0.4";s:3:"url";s:44:"https://wordpress.org/plugins/wordpress-seo/";s:7:"package";s:62:"https://downloads.wordpress.org/plugin/wordpress-seo.3.0.4.zip";}}s:12:"translations";a:0:{}s:9:"no_update";a:1:{s:36:"google-sitemap-generator/sitemap.php";O:8:"stdClass":6:{s:2:"id";s:3:"132";s:4:"slug";s:24:"google-sitemap-generator";s:6:"plugin";s:36:"google-sitemap-generator/sitemap.php";s:11:"new_version";s:5:"4.0.8";s:3:"url";s:55:"https://wordpress.org/plugins/google-sitemap-generator/";s:7:"package";s:73:"https://downloads.wordpress.org/plugin/google-sitemap-generator.4.0.8.zip";}}}', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_postmeta`
--

DROP TABLE IF EXISTS `mpb_wp_postmeta`;
CREATE TABLE IF NOT EXISTS `mpb_wp_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=360 ;

--
-- Dumping data for table `mpb_wp_postmeta`
--

INSERT INTO `mpb_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 2, '_edit_lock', '1388249170:2'),
(3, 2, '_edit_last', '1'),
(4, 6, '_edit_last', '3'),
(5, 6, '_wp_page_template', 'page-about.php'),
(6, 6, '_edit_lock', '1388247590:3'),
(7, 8, '_menu_item_type', 'post_type'),
(8, 8, '_menu_item_menu_item_parent', '0'),
(9, 8, '_menu_item_object_id', '6'),
(10, 8, '_menu_item_object', 'page'),
(11, 8, '_menu_item_target', ''),
(12, 8, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(13, 8, '_menu_item_xfn', ''),
(14, 8, '_menu_item_url', ''),
(16, 9, '_menu_item_type', 'post_type'),
(17, 9, '_menu_item_menu_item_parent', '0'),
(18, 9, '_menu_item_object_id', '2'),
(19, 9, '_menu_item_object', 'page'),
(20, 9, '_menu_item_target', ''),
(21, 9, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(22, 9, '_menu_item_xfn', ''),
(23, 9, '_menu_item_url', ''),
(24, 10, '_edit_last', '1'),
(25, 10, '_edit_lock', '1388245496:3'),
(26, 23, '_edit_last', '1'),
(27, 23, '_edit_lock', '1370090332:1'),
(28, 25, '_edit_last', '1'),
(29, 25, '_edit_lock', '1370090152:1'),
(34, 27, '_wp_attached_file', '2013/05/masseyhisquare.jpg'),
(35, 27, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2592;s:6:"height";i:1936;s:4:"file";s:26:"2013/05/masseyhisquare.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"masseyhisquare-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"masseyhisquare-640x478.jpg";s:5:"width";i:640;s:6:"height";i:478;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:27:"masseyhisquare-1024x764.jpg";s:5:"width";i:1024;s:6:"height";i:764;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2.79999999999999982236431605997495353221893310546875;s:6:"credit";s:0:"";s:6:"camera";s:8:"iPhone 4";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1354800477;s:9:"copyright";s:0:"";s:12:"focal_length";s:4:"3.85";s:3:"iso";s:2:"80";s:13:"shutter_speed";s:17:"0.000266666666667";s:5:"title";s:0:"";}}'),
(36, 27, '_wp_attachment_image_alt', 'Massey Brooks handstand'),
(38, 28, '_wp_attached_file', '2013/05/309574_10151412080862363_589646460_n.jpg'),
(39, 28, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:720;s:4:"file";s:48:"2013/05/309574_10151412080862363_589646460_n.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:48:"309574_10151412080862363_589646460_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:48:"309574_10151412080862363_589646460_n-640x640.jpg";s:5:"width";i:640;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(40, 23, '_thumbnail_id', '28'),
(41, 29, '_edit_last', '3'),
(42, 29, '_edit_lock', '1388248997:3'),
(43, 30, '_wp_attached_file', '2013/05/292320_10151178257372363_1261587978_n.jpg'),
(44, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:720;s:4:"file";s:49:"2013/05/292320_10151178257372363_1261587978_n.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:49:"292320_10151178257372363_1261587978_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:49:"292320_10151178257372363_1261587978_n-640x640.jpg";s:5:"width";i:640;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(45, 29, '_thumbnail_id', '103'),
(46, 31, '_edit_last', '3'),
(47, 31, '_edit_lock', '1388247916:3'),
(51, 33, '_edit_last', '3'),
(52, 33, '_edit_lock', '1388247881:3'),
(53, 34, '_wp_attached_file', '2013/05/MasseyPole-e1370094038108.jpg'),
(54, 34, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:301;s:6:"height";i:307;s:4:"file";s:37:"2013/05/MasseyPole-e1370094038108.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"MasseyPole-e1370094038108-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(56, 35, '_edit_last', '3'),
(57, 35, '_edit_lock', '1388246798:3'),
(58, 36, '_wp_attached_file', '2013/05/MasseyWedding.jpg'),
(59, 36, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:865;s:4:"file";s:25:"2013/05/MasseyWedding.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"MasseyWedding-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"MasseyWedding-532x640.jpg";s:5:"width";i:532;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(63, 38, '_wp_attached_file', '2013/05/MasseyTree.jpg'),
(64, 38, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:540;s:6:"height";i:720;s:4:"file";s:22:"2013/05/MasseyTree.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"MasseyTree-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"MasseyTree-480x640.jpg";s:5:"width";i:480;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(68, 40, '_wp_attached_file', '2013/05/MasseyJump.jpg'),
(69, 40, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:451;s:6:"height";i:451;s:4:"file";s:22:"2013/05/MasseyJump.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"MasseyJump-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(73, 42, '_wp_attached_file', '2013/05/MasseyApt-e1369761049737.jpg'),
(74, 42, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:499;s:4:"file";s:36:"2013/05/MasseyApt-e1369761049737.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:36:"MasseyApt-e1369761049737-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:36:"MasseyApt-e1369761049737-640x443.jpg";s:5:"width";i:640;s:6:"height";i:443;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(78, 44, '_wp_attached_file', '2013/05/MasseyCar.jpg'),
(79, 44, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:720;s:4:"file";s:21:"2013/05/MasseyCar.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:21:"MasseyCar-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:21:"MasseyCar-640x480.jpg";s:5:"width";i:640;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(83, 46, '_wp_attached_file', '2013/05/MasseyBeach.jpg'),
(84, 46, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:538;s:4:"file";s:23:"2013/05/MasseyBeach.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"MasseyBeach-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"MasseyBeach-640x478.jpg";s:5:"width";i:640;s:6:"height";i:478;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(88, 48, '_wp_attached_file', '2013/05/MasseyBlue-e1369761003439.jpg'),
(89, 48, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:715;s:6:"height";i:487;s:4:"file";s:37:"2013/05/MasseyBlue-e1369761003439.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:37:"MasseyBlue-e1369761003439-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:37:"MasseyBlue-e1369761003439-640x435.jpg";s:5:"width";i:640;s:6:"height";i:435;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(91, 48, '_edit_lock', '1369760944:1'),
(92, 48, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:716;s:6:"height";i:960;s:4:"file";s:14:"MasseyBlue.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:22:"MasseyBlue-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:22:"MasseyBlue-477x640.jpg";s:5:"width";i:477;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}'),
(93, 42, '_edit_lock', '1369761029:1'),
(94, 42, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:720;s:6:"height";i:960;s:4:"file";s:13:"MasseyApt.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:21:"MasseyApt-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:21:"MasseyApt-480x640.jpg";s:5:"width";i:480;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}'),
(108, 34, '_edit_lock', '1370094026:1'),
(109, 34, '_edit_last', '1'),
(110, 34, '_wp_attachment_backup_sizes', 'a:4:{s:9:"full-orig";a:3:{s:5:"width";i:401;s:6:"height";i:534;s:4:"file";s:14:"MasseyPole.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:22:"MasseyPole-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:18:"full-1370094038108";a:3:{s:5:"width";i:399;s:6:"height";i:309;s:4:"file";s:29:"MasseyPole-e1369762594857.jpg";}s:23:"thumbnail-1370094038108";a:4:{s:4:"file";s:37:"MasseyPole-e1369762594857-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}'),
(120, 51, '_wp_attached_file', '2013/05/MasseyMountain-e1369763802254.jpg'),
(121, 51, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:746;s:4:"file";s:41:"2013/05/MasseyMountain-e1369763802254.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:41:"MasseyMountain-e1369763802254-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:41:"MasseyMountain-e1369763802254-640x497.jpg";s:5:"width";i:640;s:6:"height";i:497;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(122, 31, '_thumbnail_id', '99'),
(123, 52, '_wp_attached_file', '2013/05/MasseyBeach1.jpg'),
(124, 52, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:538;s:4:"file";s:24:"2013/05/MasseyBeach1.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"MasseyBeach1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"MasseyBeach1-640x478.jpg";s:5:"width";i:640;s:6:"height";i:478;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(126, 53, '_wp_attached_file', '2013/05/67932_4379809009109_447377474_n.jpg'),
(127, 53, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:720;s:6:"height";i:538;s:4:"file";s:43:"2013/05/67932_4379809009109_447377474_n.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:43:"67932_4379809009109_447377474_n-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:43:"67932_4379809009109_447377474_n-640x478.jpg";s:5:"width";i:640;s:6:"height";i:478;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(130, 35, '_thumbnail_id', '89'),
(131, 54, '_wp_attached_file', '2013/05/MasseyBlue1-e1369763768957.jpg'),
(132, 54, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:715;s:6:"height";i:576;s:4:"file";s:38:"2013/05/MasseyBlue1-e1369763768957.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:38:"MasseyBlue1-e1369763768957-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:38:"MasseyBlue1-e1369763768957-640x515.jpg";s:5:"width";i:640;s:6:"height";i:515;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(133, 25, '_thumbnail_id', '54'),
(134, 54, '_edit_lock', '1369763770:1'),
(135, 54, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:716;s:6:"height";i:960;s:4:"file";s:15:"MasseyBlue1.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:23:"MasseyBlue1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:23:"MasseyBlue1-477x640.jpg";s:5:"width";i:477;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}'),
(136, 54, '_edit_last', '1'),
(137, 51, '_edit_lock', '1369763804:1'),
(138, 51, '_wp_attachment_backup_sizes', 'a:3:{s:9:"full-orig";a:3:{s:5:"width";i:960;s:6:"height";i:960;s:4:"file";s:18:"MasseyMountain.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:26:"MasseyMountain-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:26:"MasseyMountain-640x640.jpg";s:5:"width";i:640;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}'),
(139, 51, '_edit_last', '1'),
(140, 55, '_edit_last', '2'),
(142, 55, 'position', 'normal'),
(143, 55, 'layout', 'default'),
(144, 55, 'hide_on_screen', ''),
(145, 55, '_edit_lock', '1388254263:2'),
(146, 55, 'field_51a4f4c3e04a5', 'a:11:{s:3:"key";s:19:"field_51a4f4c3e04a5";s:5:"label";s:10:"Main Image";s:4:"name";s:10:"main_image";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_51a8d7b0867f4";s:8:"operator";s:2:"==";s:5:"value";s:1:"1";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:1;}'),
(148, 55, 'field_51a4f4f9facff', 'a:11:{s:3:"key";s:19:"field_51a4f4f9facff";s:5:"label";s:7:"Image 2";s:4:"name";s:7:"image_2";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_51a8d7b0867f4";s:8:"operator";s:2:"==";s:5:"value";s:1:"1";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:2;}'),
(151, 35, 'main_image', '85'),
(152, 35, '_main_image', 'field_51a4f4c3e04a5'),
(153, 35, 'image_2', '88'),
(154, 35, '_image_2', 'field_51a4f4f9facff'),
(155, 35, '_', 'field_51a4f50dfad00'),
(156, 55, 'field_51a8d7b0867f4', 'a:10:{s:3:"key";s:19:"field_51a8d7b0867f4";s:5:"label";s:18:"Show on Home Page?";s:4:"name";s:8:"featured";s:4:"type";s:10:"true_false";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:7:"message";s:0:"";s:13:"default_value";s:1:"1";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_51a8d7b0867f4";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(159, 23, 'featured', '1'),
(160, 23, '_featured', 'field_51a8d7b0867f4'),
(161, 23, 'main_image', '69'),
(162, 23, '_main_image', 'field_51a4f4c3e04a5'),
(163, 23, 'image_2', '65'),
(164, 23, '_image_2', 'field_51a4f4f9facff'),
(165, 25, 'featured', '1'),
(166, 25, '_featured', 'field_51a8d7b0867f4'),
(167, 25, 'main_image', '67'),
(168, 25, '_main_image', 'field_51a4f4c3e04a5'),
(169, 25, 'image_2', '70'),
(170, 25, '_image_2', 'field_51a4f4f9facff'),
(171, 29, 'featured', '1'),
(172, 29, '_featured', 'field_51a8d7b0867f4'),
(173, 29, 'main_image', '102'),
(174, 29, '_main_image', 'field_51a4f4c3e04a5'),
(175, 29, 'image_2', '61'),
(176, 29, '_image_2', 'field_51a4f4f9facff'),
(177, 31, 'featured', '1'),
(178, 31, '_featured', 'field_51a8d7b0867f4'),
(179, 31, 'main_image', '98'),
(180, 31, '_main_image', 'field_51a4f4c3e04a5'),
(181, 31, 'image_2', '40'),
(182, 31, '_image_2', 'field_51a4f4f9facff'),
(183, 33, 'featured', '1'),
(184, 33, '_featured', 'field_51a8d7b0867f4'),
(185, 33, 'main_image', '96'),
(186, 33, '_main_image', 'field_51a4f4c3e04a5'),
(187, 33, 'image_2', '53'),
(188, 33, '_image_2', 'field_51a4f4f9facff'),
(189, 35, 'featured', '1'),
(190, 35, '_featured', 'field_51a8d7b0867f4'),
(191, 55, 'field_51a8e85470a17', 'a:11:{s:3:"key";s:19:"field_51a8e85470a17";s:5:"label";s:7:"Image 3";s:4:"name";s:7:"image_3";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_51a8d7b0867f4";s:8:"operator";s:2:"==";s:5:"value";s:1:"1";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:3;}'),
(193, 55, 'field_51a8e878f01c5', 'a:11:{s:3:"key";s:19:"field_51a8e878f01c5";s:5:"label";s:7:"Image 4";s:4:"name";s:7:"image_4";s:4:"type";s:5:"image";s:12:"instructions";s:0:"";s:8:"required";s:1:"1";s:11:"save_format";s:6:"object";s:12:"preview_size";s:9:"thumbnail";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_51a8d7b0867f4";s:8:"operator";s:2:"==";s:5:"value";s:1:"1";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:4;}'),
(287, 55, 'rule', 'a:5:{s:5:"param";s:9:"post_type";s:8:"operator";s:2:"==";s:5:"value";s:7:"project";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(195, 33, 'image_3', '51'),
(196, 33, '_image_3', 'field_51a8e85470a17'),
(197, 33, 'image_4', '38'),
(198, 33, '_image_4', 'field_51a8e878f01c5'),
(199, 35, 'image_3', '42'),
(200, 35, '_image_3', 'field_51a8e85470a17'),
(201, 35, 'image_4', '34'),
(202, 35, '_image_4', 'field_51a8e878f01c5'),
(203, 57, '_wp_attached_file', '2013/05/MasseyFetal.jpg'),
(204, 57, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:716;s:4:"file";s:23:"2013/05/MasseyFetal.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"MasseyFetal-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"MasseyFetal-640x477.jpg";s:5:"width";i:640;s:6:"height";i:477;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(205, 31, 'image_3', '44'),
(206, 31, '_image_3', 'field_51a8e85470a17'),
(207, 31, 'image_4', '57'),
(208, 31, '_image_4', 'field_51a8e878f01c5'),
(209, 58, '_wp_attached_file', '2013/05/MasseyStanding.jpg'),
(210, 58, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:716;s:6:"height";i:960;s:4:"file";s:26:"2013/05/MasseyStanding.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"MasseyStanding-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:26:"MasseyStanding-477x640.jpg";s:5:"width";i:477;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(211, 59, '_wp_attached_file', '2013/05/MasseyGroupHI.jpg'),
(212, 59, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:960;s:6:"height";i:716;s:4:"file";s:25:"2013/05/MasseyGroupHI.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"MasseyGroupHI-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"MasseyGroupHI-640x477.jpg";s:5:"width";i:640;s:6:"height";i:477;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(213, 60, '_wp_attached_file', '2013/05/MasseyBlue2.jpg'),
(214, 60, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:716;s:6:"height";i:960;s:4:"file";s:23:"2013/05/MasseyBlue2.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"MasseyBlue2-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"MasseyBlue2-477x640.jpg";s:5:"width";i:477;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(215, 61, '_wp_attached_file', '2013/05/MasseyDying.jpg'),
(216, 61, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:716;s:6:"height";i:960;s:4:"file";s:23:"2013/05/MasseyDying.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"MasseyDying-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"MasseyDying-477x640.jpg";s:5:"width";i:477;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(217, 29, 'image_3', '59'),
(218, 29, '_image_3', 'field_51a8e85470a17'),
(219, 29, 'image_4', '60'),
(220, 29, '_image_4', 'field_51a8e878f01c5'),
(221, 63, '_wp_attached_file', '2013/05/masseygroup.jpg'),
(222, 63, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:2008;s:4:"file";s:23:"2013/05/masseygroup.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"masseygroup-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"masseygroup-478x640.jpg";s:5:"width";i:478;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"masseygroup-764x1024.jpg";s:5:"width";i:764;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(223, 64, '_wp_attached_file', '2013/05/masseyrenderform.jpg'),
(224, 64, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:800;s:6:"height";i:1568;s:4:"file";s:28:"2013/05/masseyrenderform.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"masseyrenderform-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"masseyrenderform-326x640.jpg";s:5:"width";i:326;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"masseyrenderform-522x1024.jpg";s:5:"width";i:522;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(225, 65, '_wp_attached_file', '2013/05/masseyrendercardboard.jpg'),
(226, 65, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:471;s:6:"height";i:919;s:4:"file";s:33:"2013/05/masseyrendercardboard.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:33:"masseyrendercardboard-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:33:"masseyrendercardboard-328x640.jpg";s:5:"width";i:328;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(227, 66, '_wp_attached_file', '2013/05/masseyrenderribs.jpg'),
(228, 66, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:700;s:6:"height";i:1449;s:4:"file";s:28:"2013/05/masseyrenderribs.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"masseyrenderribs-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"masseyrenderribs-309x640.jpg";s:5:"width";i:309;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"masseyrenderribs-494x1024.jpg";s:5:"width";i:494;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(229, 67, '_wp_attached_file', '2013/05/masseytrevorsanding.jpg'),
(230, 67, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:718;s:4:"file";s:31:"2013/05/masseytrevorsanding.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"masseytrevorsanding-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"masseytrevorsanding-640x459.jpg";s:5:"width";i:640;s:6:"height";i:459;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(231, 68, '_wp_attached_file', '2013/05/masseyrenderslats.jpg'),
(232, 68, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:2014;s:4:"file";s:29:"2013/05/masseyrenderslats.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"masseyrenderslats-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"masseyrenderslats-317x640.jpg";s:5:"width";i:317;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"masseyrenderslats-508x1024.jpg";s:5:"width";i:508;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(233, 69, '_wp_attached_file', '2013/05/masseychair.jpg'),
(234, 69, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:725;s:6:"height";i:1121;s:4:"file";s:23:"2013/05/masseychair.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"masseychair-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"masseychair-413x640.jpg";s:5:"width";i:413;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"masseychair-662x1024.jpg";s:5:"width";i:662;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(235, 70, '_wp_attached_file', '2013/05/masseycutoutchair.jpg'),
(236, 70, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1641;s:6:"height";i:1799;s:4:"file";s:29:"2013/05/masseycutoutchair.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:29:"masseycutoutchair-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:29:"masseycutoutchair-583x640.jpg";s:5:"width";i:583;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:30:"masseycutoutchair-934x1024.jpg";s:5:"width";i:934;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(237, 72, '_wp_attached_file', '2013/05/masseygroup1.jpg'),
(238, 72, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1500;s:6:"height";i:2008;s:4:"file";s:24:"2013/05/masseygroup1.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"masseygroup1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"masseygroup1-478x640.jpg";s:5:"width";i:478;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"masseygroup1-764x1024.jpg";s:5:"width";i:764;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(239, 73, '_wp_attached_file', '2013/05/masseychairmacro.jpg'),
(240, 73, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:28:"2013/05/masseychairmacro.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"masseychairmacro-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:28:"masseychairmacro-480x640.jpg";s:5:"width";i:480;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:29:"masseychairmacro-768x1024.jpg";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(241, 74, '_wp_attached_file', '2013/05/masseychairbuilding.jpg'),
(242, 74, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1000;s:6:"height";i:1339;s:4:"file";s:31:"2013/05/masseychairbuilding.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:31:"masseychairbuilding-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:31:"masseychairbuilding-477x640.jpg";s:5:"width";i:477;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:32:"masseychairbuilding-764x1024.jpg";s:5:"width";i:764;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(243, 75, '_wp_attached_file', '2013/05/masseysanding.jpg'),
(244, 75, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2000;s:6:"height";i:1494;s:4:"file";s:25:"2013/05/masseysanding.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:25:"masseysanding-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:25:"masseysanding-640x478.jpg";s:5:"width";i:640;s:6:"height";i:478;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:26:"masseysanding-1024x764.jpg";s:5:"width";i:1024;s:6:"height";i:764;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(245, 76, '_wp_attached_file', '2013/05/masseycardboard.jpg'),
(246, 76, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2979;s:6:"height";i:2612;s:4:"file";s:27:"2013/05/masseycardboard.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:27:"masseycardboard-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:27:"masseycardboard-640x561.jpg";s:5:"width";i:640;s:6:"height";i:561;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:28:"masseycardboard-1024x897.jpg";s:5:"width";i:1024;s:6:"height";i:897;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(247, 77, '_wp_attached_file', '2013/05/MasseySketchbook.jpg'),
(248, 77, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:500;s:6:"height";i:139;s:4:"file";s:28:"2013/05/MasseySketchbook.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:28:"MasseySketchbook-150x139.jpg";s:5:"width";i:150;s:6:"height";i:139;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(249, 78, '_wp_attached_file', '2013/05/MasseyHawaii.jpg'),
(250, 78, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2592;s:6:"height";i:1210;s:4:"file";s:24:"2013/05/MasseyHawaii.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"MasseyHawaii-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"MasseyHawaii-640x298.jpg";s:5:"width";i:640;s:6:"height";i:298;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"MasseyHawaii-1024x478.jpg";s:5:"width";i:1024;s:6:"height";i:478;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(251, 25, 'image_3', '73'),
(252, 25, '_image_3', 'field_51a8e85470a17'),
(253, 25, 'image_4', '75'),
(254, 25, '_image_4', 'field_51a8e878f01c5'),
(255, 23, 'image_3', '66'),
(256, 23, '_image_3', 'field_51a8e85470a17'),
(257, 23, 'image_4', '68'),
(258, 23, '_image_4', 'field_51a8e878f01c5'),
(259, 35, '_wp_old_slug', 'project-6'),
(260, 33, '_wp_old_slug', 'project-5'),
(261, 79, '_wp_attached_file', '2013/05/Massey4Wheeler.jpg'),
(262, 79, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:451;s:6:"height";i:595;s:4:"file";s:26:"2013/05/Massey4Wheeler.jpg";s:5:"sizes";a:1:{s:9:"thumbnail";a:4:{s:4:"file";s:26:"Massey4Wheeler-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(264, 80, '_wp_attached_file', '2013/05/MasseyBlue3.jpg'),
(265, 80, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:716;s:6:"height";i:960;s:4:"file";s:23:"2013/05/MasseyBlue3.jpg";s:5:"sizes";a:2:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"MasseyBlue3-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:23:"MasseyBlue3-477x640.jpg";s:5:"width";i:477;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(268, 33, '_thumbnail_id', '100'),
(279, 85, '_wp_attached_file', '2013/05/Hydrology_02-e1388246012582.jpg'),
(280, 85, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2502;s:6:"height";i:2065;s:4:"file";s:39:"2013/05/Hydrology_02-e1388246012582.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:39:"Hydrology_02-e1388246012582-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:39:"Hydrology_02-e1388246012582-640x528.jpg";s:5:"width";i:640;s:6:"height";i:528;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:40:"Hydrology_02-e1388246012582-1024x845.jpg";s:5:"width";i:1024;s:6:"height";i:845;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2.7999999999999998;s:6:"credit";s:13:"Massey Brooks";s:6:"camera";s:25:"Canon PowerShot SD1200 IS";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1366676137;s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.2";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";}}'),
(281, 40, '_edit_lock', '1388244573:3'),
(283, 86, '_wp_attached_file', '2013/05/Hydrology_03.jpg'),
(284, 86, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3648;s:6:"height";i:2736;s:4:"file";s:24:"2013/05/Hydrology_03.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Hydrology_03-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:24:"Hydrology_03-640x480.jpg";s:5:"width";i:640;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:25:"Hydrology_03-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2.7999999999999998;s:6:"credit";s:13:"Massey Brooks";s:6:"camera";s:25:"Canon PowerShot SD1200 IS";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1366843784;s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.2";s:3:"iso";s:2:"80";s:13:"shutter_speed";s:4:"0.01";s:5:"title";s:0:"";}}'),
(286, 55, 'field_52beeeefda88c', 'a:10:{s:3:"key";s:19:"field_52beeeefda88c";s:5:"label";s:12:"Project File";s:4:"name";s:12:"project_file";s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:6:"object";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:19:"field_51a8d7b0867f4";s:8:"operator";s:2:"==";s:5:"value";s:1:"1";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:5;}'),
(288, 87, '_wp_attached_file', '2013/05/Section_Overlay_Water.pdf'),
(289, 88, '_wp_attached_file', '2013/05/Hydrology_031-e1388245777675.jpg'),
(290, 88, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:3648;s:6:"height";i:994;s:4:"file";s:40:"2013/05/Hydrology_031-e1388245777675.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"Hydrology_031-e1388245777675-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:40:"Hydrology_031-e1388245777675-640x174.jpg";s:5:"width";i:640;s:6:"height";i:174;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:41:"Hydrology_031-e1388245777675-1024x279.jpg";s:5:"width";i:1024;s:6:"height";i:279;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2.7999999999999998;s:6:"credit";s:13:"Massey Brooks";s:6:"camera";s:25:"Canon PowerShot SD1200 IS";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1366843784;s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.2";s:3:"iso";s:2:"80";s:13:"shutter_speed";s:4:"0.01";s:5:"title";s:0:"";}}'),
(291, 35, 'project_file', '90'),
(292, 35, '_project_file', 'field_52beeeefda88c'),
(293, 88, '_edit_lock', '1388246016:3'),
(295, 88, '_wp_attachment_backup_sizes', 'a:8:{s:9:"full-orig";a:3:{s:5:"width";i:3648;s:6:"height";i:2736;s:4:"file";s:17:"Hydrology_031.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:25:"Hydrology_031-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:25:"Hydrology_031-640x480.jpg";s:5:"width";i:640;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:10:"large-orig";a:4:{s:4:"file";s:26:"Hydrology_031-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}s:18:"full-1388245777675";a:3:{s:5:"width";i:3648;s:6:"height";i:2736;s:4:"file";s:32:"Hydrology_031-e1388245727389.jpg";}s:23:"thumbnail-1388245777675";a:4:{s:4:"file";s:40:"Hydrology_031-e1388245727389-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:20:"medium-1388245777675";a:4:{s:4:"file";s:40:"Hydrology_031-e1388245727389-640x480.jpg";s:5:"width";i:640;s:6:"height";i:480;s:9:"mime-type";s:10:"image/jpeg";}s:19:"large-1388245777675";a:4:{s:4:"file";s:41:"Hydrology_031-e1388245727389-1024x768.jpg";s:5:"width";i:1024;s:6:"height";i:768;s:9:"mime-type";s:10:"image/jpeg";}}'),
(296, 85, '_edit_lock', '1388246690:3'),
(298, 85, '_wp_attachment_backup_sizes', 'a:4:{s:9:"full-orig";a:3:{s:5:"width";i:2820;s:6:"height";i:2304;s:4:"file";s:16:"Hydrology_02.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:24:"Hydrology_02-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:24:"Hydrology_02-640x522.jpg";s:5:"width";i:640;s:6:"height";i:522;s:9:"mime-type";s:10:"image/jpeg";}s:10:"large-orig";a:4:{s:4:"file";s:25:"Hydrology_02-1024x836.jpg";s:5:"width";i:1024;s:6:"height";i:836;s:9:"mime-type";s:10:"image/jpeg";}}'),
(299, 89, '_wp_attached_file', '2013/05/Hydrology_021-e1388246261800.jpg'),
(300, 89, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1452;s:6:"height";i:796;s:4:"file";s:40:"2013/05/Hydrology_021-e1388246261800.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"Hydrology_021-e1388246261800-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:40:"Hydrology_021-e1388246261800-640x350.jpg";s:5:"width";i:640;s:6:"height";i:350;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:41:"Hydrology_021-e1388246261800-1024x561.jpg";s:5:"width";i:1024;s:6:"height";i:561;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";d:2.7999999999999998;s:6:"credit";s:13:"Massey Brooks";s:6:"camera";s:25:"Canon PowerShot SD1200 IS";s:7:"caption";s:0:"";s:17:"created_timestamp";i:1366676137;s:9:"copyright";s:0:"";s:12:"focal_length";s:3:"6.2";s:3:"iso";s:3:"100";s:13:"shutter_speed";s:17:"0.016666666666667";s:5:"title";s:0:"";}}'),
(301, 89, '_edit_lock', '1388246685:3'),
(303, 89, '_wp_attachment_backup_sizes', 'a:4:{s:9:"full-orig";a:3:{s:5:"width";i:2820;s:6:"height";i:2304;s:4:"file";s:17:"Hydrology_021.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:25:"Hydrology_021-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:25:"Hydrology_021-640x522.jpg";s:5:"width";i:640;s:6:"height";i:522;s:9:"mime-type";s:10:"image/jpeg";}s:10:"large-orig";a:4:{s:4:"file";s:26:"Hydrology_021-1024x836.jpg";s:5:"width";i:1024;s:6:"height";i:836;s:9:"mime-type";s:10:"image/jpeg";}}'),
(304, 89, '_edit_last', '3'),
(305, 90, '_wp_attached_file', '2013/05/Section_Overlay_Water1.pdf'),
(306, 91, 'featured', '1'),
(307, 91, '_featured', 'field_51a8d7b0867f4'),
(308, 91, 'main_image', '85'),
(309, 91, '_main_image', 'field_51a4f4c3e04a5'),
(310, 91, 'image_2', '88'),
(311, 91, '_image_2', 'field_51a4f4f9facff'),
(312, 91, 'image_3', '42'),
(313, 91, '_image_3', 'field_51a8e85470a17'),
(314, 91, 'image_4', '34'),
(315, 91, '_image_4', 'field_51a8e878f01c5'),
(316, 91, 'project_file', '90'),
(317, 91, '_project_file', 'field_52beeeefda88c'),
(319, 92, '_edit_lock', '1388253401:2'),
(320, 92, '_edit_last', '2'),
(321, 92, 'field_52bef75afc12d', 'a:10:{s:3:"key";s:19:"field_52bef75afc12d";s:5:"label";s:2:"CV";s:4:"name";s:7:"cv_file";s:4:"type";s:4:"file";s:12:"instructions";s:0:"";s:8:"required";s:1:"0";s:11:"save_format";s:6:"object";s:7:"library";s:3:"all";s:17:"conditional_logic";a:3:{s:6:"status";s:1:"0";s:5:"rules";a:1:{i:0;a:3:{s:5:"field";s:4:"null";s:8:"operator";s:2:"==";s:5:"value";s:0:"";}}s:8:"allorany";s:3:"all";}s:8:"order_no";i:0;}'),
(326, 92, 'rule', 'a:5:{s:5:"param";s:4:"page";s:8:"operator";s:2:"==";s:5:"value";s:1:"6";s:8:"order_no";i:0;s:8:"group_no";i:0;}'),
(323, 92, 'position', 'normal'),
(324, 92, 'layout', 'default'),
(325, 92, 'hide_on_screen', ''),
(327, 93, '_wp_attached_file', '2013/05/MasseyBrooksResume_13_0930.pdf'),
(328, 94, 'cv_file', '93'),
(329, 94, '_cv_file', 'field_52bef75afc12d'),
(330, 95, 'cv_file', '93'),
(331, 95, '_cv_file', 'field_52bef75afc12d'),
(332, 6, 'cv_file', '93'),
(333, 6, '_cv_file', 'field_52bef75afc12d'),
(334, 96, '_wp_attached_file', '2013/05/Render_02_BW.png'),
(335, 96, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1218;s:6:"height";i:636;s:4:"file";s:24:"2013/05/Render_02_BW.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:24:"Render_02_BW-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:24:"Render_02_BW-640x334.png";s:5:"width";i:640;s:6:"height";i:334;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:25:"Render_02_BW-1024x534.png";s:5:"width";i:1024;s:6:"height";i:534;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(336, 33, 'project_file', ''),
(337, 33, '_project_file', 'field_52beeeefda88c'),
(338, 98, '_wp_attached_file', '2013/05/DSCN2452_BW.png'),
(339, 98, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:725;s:6:"height";i:1121;s:4:"file";s:23:"2013/05/DSCN2452_BW.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"DSCN2452_BW-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"DSCN2452_BW-413x640.png";s:5:"width";i:413;s:6:"height";i:640;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:24:"DSCN2452_BW-662x1024.png";s:5:"width";i:662;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(340, 99, '_wp_attached_file', '2013/05/DSCN2456_BW.png'),
(341, 99, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1224;s:6:"height";i:1632;s:4:"file";s:23:"2013/05/DSCN2456_BW.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:23:"DSCN2456_BW-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:23:"DSCN2456_BW-480x640.png";s:5:"width";i:480;s:6:"height";i:640;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:24:"DSCN2456_BW-768x1024.png";s:5:"width";i:768;s:6:"height";i:1024;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(342, 100, '_wp_attached_file', '2013/05/Render_02_BW1-e1388247851884.png'),
(343, 100, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:520;s:6:"height";i:319;s:4:"file";s:40:"2013/05/Render_02_BW1-e1388247851884.png";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:40:"Render_02_BW1-e1388247851884-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:25:"Render_02_BW1-640x334.png";s:5:"width";i:640;s:6:"height";i:334;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:26:"Render_02_BW1-1024x534.png";s:5:"width";i:1024;s:6:"height";i:534;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:0:"";}}'),
(344, 100, '_edit_lock', '1388247873:3');
INSERT INTO `mpb_wp_postmeta` (`meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(346, 100, '_wp_attachment_backup_sizes', 'a:4:{s:9:"full-orig";a:3:{s:5:"width";i:1218;s:6:"height";i:636;s:4:"file";s:17:"Render_02_BW1.png";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:25:"Render_02_BW1-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:11:"medium-orig";a:4:{s:4:"file";s:25:"Render_02_BW1-640x334.png";s:5:"width";i:640;s:6:"height";i:334;s:9:"mime-type";s:9:"image/png";}s:10:"large-orig";a:4:{s:4:"file";s:26:"Render_02_BW1-1024x534.png";s:5:"width";i:1024;s:6:"height";i:534;s:9:"mime-type";s:9:"image/png";}}'),
(347, 100, '_edit_last', '3'),
(348, 31, 'project_file', ''),
(349, 31, '_project_file', 'field_52beeeefda88c'),
(350, 102, '_wp_attached_file', '2013/05/Morphology.jpg'),
(351, 102, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:2010;s:6:"height";i:2010;s:4:"file";s:22:"2013/05/Morphology.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:22:"Morphology-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:22:"Morphology-640x640.jpg";s:5:"width";i:640;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:24:"Morphology-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:13:"Massey Brooks";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:8:"Untitled";}}'),
(352, 103, '_wp_attached_file', '2013/05/Morphology1-e1388248443832.jpg'),
(353, 103, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1211;s:6:"height";i:999;s:4:"file";s:38:"2013/05/Morphology1-e1388248443832.jpg";s:5:"sizes";a:3:{s:9:"thumbnail";a:4:{s:4:"file";s:38:"Morphology1-e1388248443832-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:38:"Morphology1-e1388248443832-640x527.jpg";s:5:"width";i:640;s:6:"height";i:527;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:39:"Morphology1-e1388248443832-1024x844.jpg";s:5:"width";i:1024;s:6:"height";i:844;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:10:{s:8:"aperture";i:0;s:6:"credit";s:13:"Massey Brooks";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";i:0;s:9:"copyright";s:0:"";s:12:"focal_length";i:0;s:3:"iso";i:0;s:13:"shutter_speed";i:0;s:5:"title";s:8:"Untitled";}}'),
(354, 103, '_edit_lock', '1388249024:3'),
(356, 103, '_wp_attachment_backup_sizes', 'a:4:{s:9:"full-orig";a:3:{s:5:"width";i:2010;s:6:"height";i:2010;s:4:"file";s:15:"Morphology1.jpg";}s:14:"thumbnail-orig";a:4:{s:4:"file";s:23:"Morphology1-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:11:"medium-orig";a:4:{s:4:"file";s:23:"Morphology1-640x640.jpg";s:5:"width";i:640;s:6:"height";i:640;s:9:"mime-type";s:10:"image/jpeg";}s:10:"large-orig";a:4:{s:4:"file";s:25:"Morphology1-1024x1024.jpg";s:5:"width";i:1024;s:6:"height";i:1024;s:9:"mime-type";s:10:"image/jpeg";}}'),
(357, 103, '_edit_last', '3'),
(358, 29, 'project_file', ''),
(359, 29, '_project_file', 'field_52beeeefda88c');

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_posts`
--

DROP TABLE IF EXISTS `mpb_wp_posts`;
CREATE TABLE IF NOT EXISTS `mpb_wp_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`),
  KEY `post_name` (`post_name`(191))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=104 ;

--
-- Dumping data for table `mpb_wp_posts`
--

INSERT INTO `mpb_wp_posts` (`ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2013-05-07 17:04:02', '2013-05-07 17:04:02', 'Welcome to WordPress. This is your first post. Edit or delete it, then start blogging!', 'Hello world!', '', 'publish', 'open', 'open', '', 'hello-world', '', '', '2013-05-07 17:04:02', '2013-05-07 17:04:02', '', 0, 'http://localhost/Massey/?p=1', 0, 'post', '', 0),
(2, 1, '2013-05-07 17:04:02', '2013-05-07 17:04:02', '', 'Projects', '', 'publish', 'open', 'open', '', 'projects', '', '', '2013-05-21 15:54:36', '2013-05-21 15:54:36', '', 0, 'http://localhost/Massey/?page_id=2', 0, 'page', '', 0),
(4, 1, '2013-05-07 17:04:02', '2013-05-07 17:04:02', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\n\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like pi&#241;a coladas. (And gettin'' caught in the rain.)</blockquote>\n\n...or something like this:\n\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\n\nAs a new WordPress user, you should go to <a href="http://localhost/Massey/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Sample Page', '', 'inherit', 'open', 'open', '', '2-revision', '', '', '2013-05-07 17:04:02', '2013-05-07 17:04:02', '', 2, 'http://localhost/Massey/?p=4', 0, 'revision', '', 0),
(5, 1, '2013-05-07 17:12:11', '2013-05-07 17:12:11', 'This is an example page. It''s different from a blog post because it will stay in one place and will show up in your site navigation (in most themes). Most people start with an About page that introduces them to potential site visitors. It might say something like this:\r\n<blockquote>Hi there! I''m a bike messenger by day, aspiring actor by night, and this is my blog. I live in Los Angeles, have a great dog named Jack, and I like piña coladas. (And gettin'' caught in the rain.)</blockquote>\r\n...or something like this:\r\n<blockquote>The XYZ Doohickey Company was founded in 1971, and has been providing quality doohickeys to the public ever since. Located in Gotham City, XYZ employs over 2,000 people and does all kinds of awesome things for the Gotham community.</blockquote>\r\nAs a new WordPress user, you should go to <a href="http://localhost/Massey/wp-admin/">your dashboard</a> to delete this page and create new pages for your content. Have fun!', 'Projects', '', 'inherit', 'open', 'open', '', '2-revision-2', '', '', '2013-05-07 17:12:11', '2013-05-07 17:12:11', '', 2, 'http://localhost/Massey/?p=5', 0, 'revision', '', 0),
(6, 1, '2013-05-07 17:12:38', '2013-05-07 17:12:38', 'Well, the way they make shows is, they make one show. That show''s called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they''re going to make more shows. Some pilots get picked and become television programs. Some don''t, become nothing. She starred in one of the ones that became nothing.\r\n\r\nDo you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it? Do you see a little Asian child with a blank expression on his face sitting outside on a mechanical helicopter that shakes when you put quarters in it? No? Well, that''s what you see at a toy store. And you must think you''re in a toy store, because you''re here shopping for an infant named Jeb.', 'About', '', 'publish', 'open', 'open', '', 'about', '', '', '2013-12-28 16:14:11', '2013-12-28 16:14:11', '', 0, 'http://localhost/Massey/?page_id=6', 0, 'page', '', 0),
(7, 1, '2013-05-07 17:12:38', '2013-05-07 17:12:38', '', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-07 17:12:38', '2013-05-07 17:12:38', '', 6, 'http://localhost/Massey/?p=7', 0, 'revision', '', 0),
(8, 1, '2013-05-07 17:13:00', '2013-05-07 17:13:00', ' ', '', '', 'publish', 'open', 'open', '', '8', '', '', '2013-05-07 17:13:00', '2013-05-07 17:13:00', '', 0, 'http://localhost/Massey/?p=8', 2, 'nav_menu_item', '', 0),
(9, 1, '2013-05-07 17:13:00', '2013-05-07 17:13:00', ' ', '', '', 'publish', 'open', 'open', '', '9', '', '', '2013-05-07 17:13:00', '2013-05-07 17:13:00', '', 0, 'http://localhost/Massey/?p=9', 1, 'nav_menu_item', '', 0),
(10, 1, '2013-05-10 15:54:56', '2013-05-10 15:54:56', 'bloogy bloo', 'Home', '', 'publish', 'open', 'open', '', 'home', '', '', '2013-05-10 18:33:10', '2013-05-10 18:33:10', '', 0, 'http://localhost/Massey/?page_id=10', 0, 'page', '', 0),
(11, 1, '2013-05-10 15:54:56', '2013-05-10 15:54:56', '', 'Home', '', 'inherit', 'open', 'open', '', '10-revision', '', '', '2013-05-10 15:54:56', '2013-05-10 15:54:56', '', 10, 'http://localhost/Massey/2013/05/10-revision/', 0, 'revision', '', 0),
(88, 3, '2013-12-28 15:45:34', '2013-12-28 15:45:34', '', 'Hydrology_03', '', 'inherit', 'open', 'open', '', 'hydrology_03-2', '', '', '2013-12-28 15:45:34', '2013-12-28 15:45:34', '', 35, 'http://masseybrooks.com/wp-content/uploads/2013/05/Hydrology_031.jpg', 0, 'attachment', 'image/jpeg', 0),
(14, 1, '2013-05-07 17:12:41', '2013-05-07 17:12:41', '', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-07 17:12:41', '2013-05-07 17:12:41', '', 6, 'http://localhost/Massey/2013/05/6-revision-2/', 0, 'revision', '', 0),
(15, 1, '2013-05-16 15:45:28', '2013-05-16 15:45:28', '', 'Poopy', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 15:45:28', '2013-05-16 15:45:28', '', 6, 'http://localhost/Massey/2013/05/6-revision-3/', 0, 'revision', '', 0),
(16, 1, '2013-05-16 15:45:40', '2013-05-16 15:45:40', '', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 15:45:40', '2013-05-16 15:45:40', '', 6, 'http://localhost/Massey/2013/05/6-revision-4/', 0, 'revision', '', 0),
(17, 1, '2013-05-16 15:49:11', '2013-05-16 15:49:11', 'Now that there is the Tec-9, a crappy spray gun from South Miami. This gun is advertised as the most popular gun in American crime. Do you believe that shit? It actually says that in the little book that comes with it: the most popular gun in American crime. Like they''re actually proud of that shit.\n\nWell, the way they make shows is, they make one show. That show''s called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they''re going to make more shows. Some pilots get picked and become television programs. Some don''t, become nothing. She starred in one of the ones that became nothing.\n\nDo you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it? Do you see a little Asian child with a blank expression on his face sitting outside on a mechanical helicopter that shakes when you put quarters in it? No? Well, that''s what you see at a toy store. And you must think you''re in a toy store, because you''re here shopping for an infant named Jeb.\n\nMotherfuckers.', 'About', '', 'inherit', 'open', 'open', '', '6-autosave-v1', '', '', '2013-05-16 15:49:11', '2013-05-16 15:49:11', '', 6, 'http://localhost/Massey/2013/05/6-autosave/', 0, 'revision', '', 0),
(18, 1, '2013-05-16 15:47:07', '2013-05-16 15:47:07', 'The path of the righteous man is beset on all sides by the iniquities of the selfish and the tyranny of evil men. Blessed is he who, in the name of charity and good will, shepherds the weak through the valley of darkness, for he is truly his brother''s keeper and the finder of lost children. And I will strike down upon thee with great vengeance and furious anger those who would attempt to poison and destroy My brothers. And you will know My name is the Lord when I lay My vengeance upon thee.', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 15:47:07', '2013-05-16 15:47:07', '', 6, 'http://localhost/Massey/2013/05/6-revision-5/', 0, 'revision', '', 0),
(19, 1, '2013-05-16 15:48:10', '2013-05-16 15:48:10', 'Now that there is the Tec-9, a crappy spray gun from South Miami. This gun is advertised as the most popular gun in American crime. Do you believe that shit? It actually says that in the little book that comes with it: the most popular gun in American crime. Like they''re actually proud of that shit.\r\n\r\nWell, the way they make shows is, they make one show. That show''s called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they''re going to make more shows. Some pilots get picked and become television programs. Some don''t, become nothing. She starred in one of the ones that became nothing.\r\n\r\nDo you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it? Do you see a little Asian child with a blank expression on his face sitting outside on a mechanical helicopter that shakes when you put quarters in it? No? Well, that''s what you see at a toy store. And you must think you''re in a toy store, because you''re here shopping for an infant named Jeb.\r\n\r\nMotherfuckers.', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 15:48:10', '2013-05-16 15:48:10', '', 6, 'http://localhost/Massey/2013/05/6-revision-6/', 0, 'revision', '', 0),
(20, 1, '2013-05-16 17:19:35', '2013-05-16 17:19:35', 'Well, the way they make shows is, they make one show. That show''s called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they''re going to make more shows. Some pilots get picked and become television programs. Some don''t, become nothing. She starred in one of the ones that became nothing.\r\n\r\nDo you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it? Do you see a little Asian child with a blank expression on his face sitting outside on a mechanical helicopter that shakes when you put quarters in it? No? Well, that''s what you see at a toy store. And you must think you''re in a toy store, because you''re here shopping for an infant named Jeb.\r\n\r\nMotherfuckers.', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 17:19:35', '2013-05-16 17:19:35', '', 6, 'http://localhost/Massey/2013/05/6-revision-7/', 0, 'revision', '', 0),
(21, 1, '2013-05-16 20:09:35', '2013-05-16 20:09:35', 'Well, the way they make shows is, they make one show. That show''s called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they''re going to make more shows. Some pilots get picked and become television programs. Some don''t, become nothing. She starred in one of the ones that became nothing.\r\n\r\nDo you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it? Do you see a little Asian child with a blank expression on his face sitting outside on a mechanical helicopter that shakes when you put quarters in it? No? Well, that''s what you see at a toy store. And you must think you''re in a toy store, because you''re here shopping for an infant named Jeb.\r\n', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 20:09:35', '2013-05-16 20:09:35', '', 6, 'http://localhost/Massey/2013/05/6-revision-8/', 0, 'revision', '', 0),
(22, 1, '2013-05-16 20:17:32', '2013-05-16 20:17:32', 'Allegra Alexander is amazing!!!!\r\n', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 20:17:32', '2013-05-16 20:17:32', '', 6, 'http://localhost/Massey/2013/05/6-revision-9/', 0, 'revision', '', 0),
(23, 1, '2013-05-21 15:53:47', '2013-05-21 15:53:47', 'Now that there is the Tec-9, a crappy spray gun from South Miami. This gun is advertised as the most popular gun in American crime. Do you believe that shit? It actually says that in the little book that comes with it: the most popular gun in American crime. Like they''re actually proud of that shit.', 'Choipin and boipin', '', 'publish', 'closed', 'closed', '', 'project-1', '', '', '2013-06-01 12:39:25', '2013-06-01 12:39:25', '', 0, 'http://localhost/Massey/?post_type=project&#038;p=23', 0, 'project', '', 0),
(24, 1, '2013-05-07 17:12:19', '2013-05-07 17:12:19', '', 'Projects', '', 'inherit', 'open', 'open', '', '2-revision-3', '', '', '2013-05-07 17:12:19', '2013-05-07 17:12:19', '', 2, 'http://localhost/Massey/2013/05/2-revision-3/', 0, 'revision', '', 0),
(25, 1, '2013-05-21 16:00:23', '2013-05-21 16:00:23', 'Normally, both your asses would be dead as fucking fried chicken, but you happen to pull this shit while I''m in a transitional period so I don''t wanna kill you, I wanna help you. But I can''t give you this case, it don''t belong to me. Besides, I''ve already been through too much shit this morning over this case to hand it over to your dumb ass.', 'Sittin on a coib', '', 'publish', 'closed', 'closed', '', 'project-2', '', '', '2013-06-01 12:37:45', '2013-06-01 12:37:45', '', 0, 'http://localhost/Massey/?post_type=project&#038;p=25', 0, 'project', '', 0),
(27, 1, '2013-05-21 16:12:36', '2013-05-21 16:12:36', '', 'masseyhisquare', '', 'inherit', 'open', 'open', '', 'masseyhisquare', '', '', '2013-05-21 16:12:36', '2013-05-21 16:12:36', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseyhisquare.jpg', 0, 'attachment', 'image/jpeg', 0),
(28, 1, '2013-05-21 16:36:40', '2013-05-21 16:36:40', '', '309574_10151412080862363_589646460_n', '', 'inherit', 'open', 'open', '', '309574_10151412080862363_589646460_n', '', '', '2013-05-21 16:36:40', '2013-05-21 16:36:40', '', 23, 'http://localhost/Massey/wp-content/uploads/2013/05/309574_10151412080862363_589646460_n.jpg', 0, 'attachment', 'image/jpeg', 0),
(29, 1, '2013-05-21 16:38:56', '2013-05-21 16:38:56', 'My money''s in that office, right? If she start giving me some bullshit about it ain''t there, and we got to go someplace else and get it, I''m gonna shoot you in the head then and there. Then I''m gonna shoot that bitch in the kneecaps, find out where my goddamn money is. She gonna tell me too. Hey, look at me when I''m talking to you, motherfucker. You listen: we go in there, and that nigga Winston or anybody else is in there, you the first motherfucker to get shot. You understand?', 'Morphology', '', 'publish', 'closed', 'closed', '', 'project-3', '', '', '2013-12-28 16:45:05', '2013-12-28 16:45:05', '', 0, 'http://localhost/Massey/?post_type=project&#038;p=29', 0, 'project', '', 0),
(30, 1, '2013-05-21 16:38:49', '2013-05-21 16:38:49', '', '292320_10151178257372363_1261587978_n', '', 'inherit', 'open', 'open', '', '292320_10151178257372363_1261587978_n', '', '', '2013-05-21 16:38:49', '2013-05-21 16:38:49', '', 29, 'http://localhost/Massey/wp-content/uploads/2013/05/292320_10151178257372363_1261587978_n.jpg', 0, 'attachment', 'image/jpeg', 0),
(31, 1, '2013-05-21 16:43:45', '2013-05-21 16:43:45', 'Look, just because I don''t be givin'' no man a foot massage don''t make it right for Marsellus to throw Antwone into a glass motherfuckin'' house, fuckin'' up the way the nigger talks. Motherfucker do that shit to me, he better paralyze my ass, ''cause I''ll kill the motherfucker, know what I''m sayin''?', 'Wave Chair', '', 'publish', 'closed', 'closed', '', 'project-4', '', '', '2013-12-28 16:25:16', '2013-12-28 16:25:16', '', 0, 'http://localhost/Massey/?post_type=project&#038;p=31', 0, 'project', '', 0),
(33, 1, '2013-05-21 16:44:43', '2013-05-21 16:44:43', 'You think water moves fast? You should see ice. It moves like it has a mind. Like it knows it killed the world once and got a taste for murder. After the avalanche, it took us a week to climb out. Now, I don''t know exactly when we turned on each other, but I know that seven of us survived the slide... and only five made it out. Now we took an oath, that I''m breaking now. We said we''d say it was the snow that killed the other two, but it wasn''t. Nature is lethal but it doesn''t hold a candle to man.\r\n\r\nYour bones don''t break, mine do. That''s clear. Your cells react to bacteria and viruses differently than mine. You don''t get sick, I do. That''s also clear. But for some reason, you and I react the exact same way to water. We swallow it too fast, we choke. We get some in our lungs, we drown. However unreal it may seem, we are connected, you and I. We''re on the same curve, just on opposite ends.\r\n\r\n<!-- please do not remove this line -->\r\n<div style="display: none;"><a href="http://slipsum.com">lorem ipsum</a></div>\r\n<!-- end slipsum code -->', 'Professionalism', '', 'publish', 'closed', 'closed', '', 'himassey', '', '', '2013-12-28 16:20:43', '2013-12-28 16:20:43', '', 0, 'http://localhost/Massey/?post_type=project&#038;p=33', 0, 'project', '', 0),
(34, 1, '2013-05-21 16:44:36', '2013-05-21 16:44:36', '', 'MasseyPole', '', 'inherit', 'open', 'open', '', 'masseypole', '', '', '2013-05-21 16:44:36', '2013-05-21 16:44:36', '', 33, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyPole.jpg', 0, 'attachment', 'image/jpeg', 0),
(35, 1, '2013-05-21 16:45:03', '2013-05-21 16:45:03', 'The path of the righteous man is beset on all sides by the iniquities of the selfish and the tyranny of evil men. Blessed is he who, in the name of charity and good will, shepherds the weak through the valley of darkness, for he is truly his brother''s keeper and the finder of lost children. And I will strike down upon thee with great vengeance and furious anger those who would attempt to poison and destroy My brothers. And you will know My name is the Lord when I lay My vengeance upon thee.', 'Hydrology', '', 'publish', 'closed', 'closed', '', 'edityourpermalinksinwordpress', '', '', '2013-12-28 16:02:30', '2013-12-28 16:02:30', '', 0, 'http://localhost/Massey/?post_type=project&#038;p=35', 0, 'project', '', 0),
(36, 1, '2013-05-21 16:45:00', '2013-05-21 16:45:00', '', 'MasseyWedding', '', 'inherit', 'open', 'open', '', 'masseywedding', '', '', '2013-05-21 16:45:00', '2013-05-21 16:45:00', '', 35, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyWedding.jpg', 0, 'attachment', 'image/jpeg', 0),
(38, 1, '2013-05-21 16:45:27', '2013-05-21 16:45:27', '', 'MasseyTree', '', 'inherit', 'open', 'open', '', 'masseytree', '', '', '2013-05-21 16:45:27', '2013-05-21 16:45:27', '', 0, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyTree.jpg', 0, 'attachment', 'image/jpeg', 0),
(40, 1, '2013-05-21 16:45:51', '2013-05-21 16:45:51', '', 'MasseyJump', '', 'inherit', 'open', 'open', '', 'masseyjump', '', '', '2013-05-21 16:45:51', '2013-05-21 16:45:51', '', 0, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyJump.jpg', 0, 'attachment', 'image/jpeg', 0),
(42, 1, '2013-05-21 16:46:38', '2013-05-21 16:46:38', '', 'MasseyApt', '', 'inherit', 'open', 'open', '', 'masseyapt', '', '', '2013-05-21 16:46:38', '2013-05-21 16:46:38', '', 0, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyApt.jpg', 0, 'attachment', 'image/jpeg', 0),
(44, 1, '2013-05-21 16:47:02', '2013-05-21 16:47:02', '', 'MasseyCar', '', 'inherit', 'open', 'open', '', 'masseycar', '', '', '2013-05-21 16:47:02', '2013-05-21 16:47:02', '', 0, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyCar.jpg', 0, 'attachment', 'image/jpeg', 0),
(46, 1, '2013-05-21 16:49:33', '2013-05-21 16:49:33', '', 'MasseyBeach', '', 'inherit', 'open', 'open', '', 'masseybeach', '', '', '2013-05-21 16:49:33', '2013-05-21 16:49:33', '', 0, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyBeach.jpg', 0, 'attachment', 'image/jpeg', 0),
(48, 1, '2013-05-21 16:51:56', '2013-05-21 16:51:56', '', 'MasseyBlue', '', 'inherit', 'open', 'open', '', 'masseyblue', '', '', '2013-05-21 16:51:56', '2013-05-21 16:51:56', '', 0, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyBlue.jpg', 0, 'attachment', 'image/jpeg', 0),
(51, 1, '2013-05-28 17:49:49', '2013-05-28 17:49:49', '', 'MasseyMountain', '', 'inherit', 'open', 'open', '', 'masseymountain', '', '', '2013-05-28 17:49:49', '2013-05-28 17:49:49', '', 31, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyMountain.jpg', 0, 'attachment', 'image/jpeg', 0),
(52, 1, '2013-05-28 17:50:19', '2013-05-28 17:50:19', '', 'MasseyBeach', '', 'inherit', 'open', 'open', '', 'masseybeach-2', '', '', '2013-05-28 17:50:19', '2013-05-28 17:50:19', '', 35, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyBeach1.jpg', 0, 'attachment', 'image/jpeg', 0),
(53, 1, '2013-05-28 17:52:25', '2013-05-28 17:52:25', '', '67932_4379809009109_447377474_n', '', 'inherit', 'open', 'open', '', '67932_4379809009109_447377474_n', '', '', '2013-05-28 17:52:25', '2013-05-28 17:52:25', '', 35, 'http://localhost/Massey/wp-content/uploads/2013/05/67932_4379809009109_447377474_n.jpg', 0, 'attachment', 'image/jpeg', 0),
(54, 1, '2013-05-28 17:55:21', '2013-05-28 17:55:21', '', 'MasseyBlue', '', 'inherit', 'open', 'open', '', 'masseyblue-2', '', '', '2013-05-28 17:55:21', '2013-05-28 17:55:21', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyBlue1.jpg', 0, 'attachment', 'image/jpeg', 0),
(55, 1, '2013-05-28 18:17:37', '2013-05-28 18:17:37', '', 'Project', '', 'publish', 'closed', 'closed', '', 'acf_project', '', '', '2013-12-28 15:33:03', '2013-12-28 15:33:03', '', 0, 'http://localhost/Massey/?post_type=acf&#038;p=55', 0, 'acf', '', 0),
(56, 1, '2013-06-01 13:39:35', '2013-06-01 13:39:35', 'You think water moves fast? You should see ice. It moves like it has a mind. Like it knows it killed the world once and got a taste for murder. After the avalanche, it took us a week to climb out. Now, I don''t know exactly when we turned on each other, but I know that seven of us survived the slide... and only five made it out. Now we took an oath, that I''m breaking now. We said we''d say it was the snow that killed the other two, but it wasn''t. Nature is lethal but it doesn''t hold a candle to man.\n\nYour bones don''t break, mine do. That''s clear. Your cells react to bacteria and viruses differently than mine. You don''t get sick, I do. That''s also clear. But for some reason, you and I react the exact same way to water. We swallow it too fast, we choke. We get some in our lungs, we drown. However unreal it may seem, we are connected, you and I. We''re on the same curve, just on opposite ends.\n\n<!-- please do not remove this line -->\n<div style="display: none;"><a href="http://slipsum.com">lorem ipsum</a></div>\n<!-- end slipsum code -->', 'name these', '', 'inherit', 'open', 'open', '', '33-autosave', '', '', '2013-06-01 13:39:35', '2013-06-01 13:39:35', '', 33, 'http://localhost/Massey/2013/05/33-autosave/', 0, 'revision', '', 0),
(57, 1, '2013-06-01 12:33:57', '2013-06-01 12:33:57', '', 'MasseyFetal', '', 'inherit', 'open', 'open', '', 'masseyfetal', '', '', '2013-06-01 12:33:57', '2013-06-01 12:33:57', '', 31, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyFetal.jpg', 0, 'attachment', 'image/jpeg', 0),
(58, 1, '2013-06-01 12:35:30', '2013-06-01 12:35:30', '', 'MasseyStanding', '', 'inherit', 'open', 'open', '', 'masseystanding', '', '', '2013-06-01 12:35:30', '2013-06-01 12:35:30', '', 29, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyStanding.jpg', 0, 'attachment', 'image/jpeg', 0),
(59, 1, '2013-06-01 12:35:48', '2013-06-01 12:35:48', '', 'MasseyGroupHI', '', 'inherit', 'open', 'open', '', 'masseygrouphi', '', '', '2013-06-01 12:35:48', '2013-06-01 12:35:48', '', 29, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyGroupHI.jpg', 0, 'attachment', 'image/jpeg', 0),
(60, 1, '2013-06-01 12:35:48', '2013-06-01 12:35:48', '', 'MasseyBlue', '', 'inherit', 'open', 'open', '', 'masseyblue-3', '', '', '2013-06-01 12:35:48', '2013-06-01 12:35:48', '', 29, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyBlue2.jpg', 0, 'attachment', 'image/jpeg', 0),
(61, 1, '2013-06-01 12:35:49', '2013-06-01 12:35:49', '', 'MasseyDying', '', 'inherit', 'open', 'open', '', 'masseydying', '', '', '2013-06-01 12:35:49', '2013-06-01 12:35:49', '', 29, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyDying.jpg', 0, 'attachment', 'image/jpeg', 0),
(101, 3, '2013-12-28 16:32:25', '2013-12-28 16:32:25', 'My money''s in that office, right? If she start giving me some bullshit about it ain''t there, and we got to go someplace else and get it, I''m gonna shoot you in the head then and there. Then I''m gonna shoot that bitch in the kneecaps, find out where my goddamn money is. She gonna tell me too. Hey, look at me when I''m talking to you, motherfucker. You listen: we go in there, and that nigga Winston or anybody else is in there, you the first motherfucker to get shot. You understand?', 'Morphology', '', 'inherit', 'open', 'open', '', '29-autosave-v1', '', '', '2013-12-28 16:32:25', '2013-12-28 16:32:25', '', 29, 'http://masseybrooks.com/2013/12/29-autosave-v1/', 0, 'revision', '', 0),
(63, 1, '2013-06-01 12:37:03', '2013-06-01 12:37:03', '', 'masseygroup', '', 'inherit', 'open', 'open', '', 'masseygroup', '', '', '2013-06-01 12:37:03', '2013-06-01 12:37:03', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseygroup.jpg', 0, 'attachment', 'image/jpeg', 0),
(64, 1, '2013-06-01 12:37:17', '2013-06-01 12:37:17', '', 'masseyrenderform', '', 'inherit', 'open', 'open', '', 'masseyrenderform', '', '', '2013-06-01 12:37:17', '2013-06-01 12:37:17', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseyrenderform.jpg', 0, 'attachment', 'image/jpeg', 0),
(65, 1, '2013-06-01 12:37:18', '2013-06-01 12:37:18', '', 'masseyrendercardboard', '', 'inherit', 'open', 'open', '', 'masseyrendercardboard', '', '', '2013-06-01 12:37:18', '2013-06-01 12:37:18', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseyrendercardboard.jpg', 0, 'attachment', 'image/jpeg', 0),
(66, 1, '2013-06-01 12:37:18', '2013-06-01 12:37:18', '', 'masseyrenderribs', '', 'inherit', 'open', 'open', '', 'masseyrenderribs', '', '', '2013-06-01 12:37:18', '2013-06-01 12:37:18', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseyrenderribs.jpg', 0, 'attachment', 'image/jpeg', 0),
(67, 1, '2013-06-01 12:37:19', '2013-06-01 12:37:19', '', 'masseytrevorsanding', '', 'inherit', 'open', 'open', '', 'masseytrevorsanding', '', '', '2013-06-01 12:37:19', '2013-06-01 12:37:19', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseytrevorsanding.jpg', 0, 'attachment', 'image/jpeg', 0),
(68, 1, '2013-06-01 12:37:19', '2013-06-01 12:37:19', '', 'masseyrenderslats', '', 'inherit', 'open', 'open', '', 'masseyrenderslats', '', '', '2013-06-01 12:37:19', '2013-06-01 12:37:19', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseyrenderslats.jpg', 0, 'attachment', 'image/jpeg', 0),
(69, 1, '2013-06-01 12:37:20', '2013-06-01 12:37:20', '', 'masseychair', '', 'inherit', 'open', 'open', '', 'masseychair', '', '', '2013-06-01 12:37:20', '2013-06-01 12:37:20', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseychair.jpg', 0, 'attachment', 'image/jpeg', 0),
(70, 1, '2013-06-01 12:37:21', '2013-06-01 12:37:21', '', 'masseycutoutchair', '', 'inherit', 'open', 'open', '', 'masseycutoutchair', '', '', '2013-06-01 12:37:21', '2013-06-01 12:37:21', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseycutoutchair.jpg', 0, 'attachment', 'image/jpeg', 0),
(71, 1, '2013-06-01 12:37:22', '2013-06-01 12:37:22', 'Normally, both your asses would be dead as fucking fried chicken, but you happen to pull this shit while I''m in a transitional period so I don''t wanna kill you, I wanna help you. But I can''t give you this case, it don''t belong to me. Besides, I''ve already been through too much shit this morning over this case to hand it over to your dumb ass.', 'Sittin on a coib', '', 'inherit', 'open', 'open', '', '25-autosave', '', '', '2013-06-01 12:37:22', '2013-06-01 12:37:22', '', 25, 'http://localhost/Massey/2013/06/25-autosave/', 0, 'revision', '', 0),
(72, 1, '2013-06-01 12:37:23', '2013-06-01 12:37:23', '', 'masseygroup', '', 'inherit', 'open', 'open', '', 'masseygroup-2', '', '', '2013-06-01 12:37:23', '2013-06-01 12:37:23', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseygroup1.jpg', 0, 'attachment', 'image/jpeg', 0),
(73, 1, '2013-06-01 12:37:25', '2013-06-01 12:37:25', '', 'masseychairmacro', '', 'inherit', 'open', 'open', '', 'masseychairmacro', '', '', '2013-06-01 12:37:25', '2013-06-01 12:37:25', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseychairmacro.jpg', 0, 'attachment', 'image/jpeg', 0),
(74, 1, '2013-06-01 12:37:26', '2013-06-01 12:37:26', '', 'masseychairbuilding', '', 'inherit', 'open', 'open', '', 'masseychairbuilding', '', '', '2013-06-01 12:37:26', '2013-06-01 12:37:26', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseychairbuilding.jpg', 0, 'attachment', 'image/jpeg', 0),
(75, 1, '2013-06-01 12:37:27', '2013-06-01 12:37:27', '', 'masseysanding', '', 'inherit', 'open', 'open', '', 'masseysanding', '', '', '2013-06-01 12:37:27', '2013-06-01 12:37:27', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseysanding.jpg', 0, 'attachment', 'image/jpeg', 0),
(76, 1, '2013-06-01 12:37:29', '2013-06-01 12:37:29', '', 'masseycardboard', '', 'inherit', 'open', 'open', '', 'masseycardboard', '', '', '2013-06-01 12:37:29', '2013-06-01 12:37:29', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/masseycardboard.jpg', 0, 'attachment', 'image/jpeg', 0),
(77, 1, '2013-06-01 12:37:32', '2013-06-01 12:37:32', '', 'MasseySketchbook', '', 'inherit', 'open', 'open', '', 'masseysketchbook', '', '', '2013-06-01 12:37:32', '2013-06-01 12:37:32', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseySketchbook.jpg', 0, 'attachment', 'image/jpeg', 0),
(78, 1, '2013-06-01 12:37:32', '2013-06-01 12:37:32', '', 'MasseyHawaii', '', 'inherit', 'open', 'open', '', 'masseyhawaii', '', '', '2013-06-01 12:37:32', '2013-06-01 12:37:32', '', 25, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyHawaii.jpg', 0, 'attachment', 'image/jpeg', 0),
(79, 1, '2013-06-01 13:38:30', '2013-06-01 13:38:30', '', 'Massey4Wheeler', '', 'inherit', 'open', 'open', '', 'massey4wheeler', '', '', '2013-06-01 13:38:30', '2013-06-01 13:38:30', '', 33, 'http://localhost/Massey/wp-content/uploads/2013/05/Massey4Wheeler.jpg', 0, 'attachment', 'image/jpeg', 0),
(80, 1, '2013-06-01 13:39:07', '2013-06-01 13:39:07', '', 'MasseyBlue', '', 'inherit', 'open', 'open', '', 'masseyblue-4', '', '', '2013-06-01 13:39:07', '2013-06-01 13:39:07', '', 33, 'http://localhost/Massey/wp-content/uploads/2013/05/MasseyBlue3.jpg', 0, 'attachment', 'image/jpeg', 0),
(85, 3, '2013-12-28 15:26:41', '2013-12-28 15:26:41', '', 'Hydrology Interior Rendering', '', 'inherit', 'open', 'open', '', 'hydrology_02', '', '', '2013-12-28 15:26:41', '2013-12-28 15:26:41', '', 35, 'http://masseybrooks.com/wp-content/uploads/2013/05/Hydrology_02.jpg', 0, 'attachment', 'image/jpeg', 0),
(86, 3, '2013-12-28 15:30:13', '2013-12-28 15:30:13', '', 'Hydrology_03', '', 'inherit', 'open', 'open', '', 'hydrology_03', '', '', '2013-12-28 15:30:13', '2013-12-28 15:30:13', '', 35, 'http://masseybrooks.com/wp-content/uploads/2013/05/Hydrology_03.jpg', 0, 'attachment', 'image/jpeg', 0),
(87, 3, '2013-12-28 15:34:21', '2013-12-28 15:34:21', '', 'Section_Overlay_Water', '', 'inherit', 'open', 'open', '', 'section_overlay_water', '', '', '2013-12-28 15:34:21', '2013-12-28 15:34:21', '', 35, 'http://masseybrooks.com/wp-content/uploads/2013/05/Section_Overlay_Water.pdf', 0, 'attachment', 'application/pdf', 0),
(89, 3, '2013-12-28 15:57:04', '2013-12-28 15:57:04', '', 'Hydrology_02', '', 'inherit', 'open', 'open', '', 'hydrology_02-2', '', '', '2013-12-28 15:57:04', '2013-12-28 15:57:04', '', 35, 'http://masseybrooks.com/wp-content/uploads/2013/05/Hydrology_021.jpg', 0, 'attachment', 'image/jpeg', 0),
(90, 3, '2013-12-28 16:02:24', '2013-12-28 16:02:24', '', 'Section_Overlay_Water', '', 'inherit', 'open', 'open', '', 'section_overlay_water-2', '', '', '2013-12-28 16:02:24', '2013-12-28 16:02:24', '', 35, 'http://masseybrooks.com/wp-content/uploads/2013/05/Section_Overlay_Water1.pdf', 0, 'attachment', 'application/pdf', 0),
(91, 3, '2013-12-28 16:05:19', '2013-12-28 16:05:19', 'The path of the righteous man is beset on all sides by the iniquities of the selfish and the tyranny of evil men. Blessed is he who, in the name of charity and good will, shepherds the weak through the valley of darkness, for he is truly his brother''s keeper and the finder of lost children. And I will strike down upon thee with great vengeance and furious anger those who would attempt to poison and destroy My brothers. And you will know My name is the Lord when I lay My vengeance upon thee.', 'Hydrology', '', 'inherit', 'open', 'open', '', '35-autosave-v1', '', '', '2013-12-28 16:05:19', '2013-12-28 16:05:19', '', 35, 'http://masseybrooks.com/2013/12/35-autosave-v1/', 0, 'revision', '', 0),
(92, 2, '2013-12-28 16:08:48', '2013-12-28 16:08:48', '', 'About', '', 'publish', 'closed', 'closed', '', 'acf_about', '', '', '2013-12-28 16:13:13', '2013-12-28 16:13:13', '', 0, 'http://masseybrooks.com/?post_type=acf&#038;p=92', 0, 'acf', '', 0),
(93, 3, '2013-12-28 16:13:44', '2013-12-28 16:13:44', '', 'MasseyBrooksResume_13_0930', '', 'inherit', 'open', 'open', '', 'masseybrooksresume_13_0930', '', '', '2013-12-28 16:13:44', '2013-12-28 16:13:44', '', 6, 'http://masseybrooks.com/wp-content/uploads/2013/05/MasseyBrooksResume_13_0930.pdf', 0, 'attachment', 'application/pdf', 0),
(94, 3, '2013-05-16 20:18:11', '2013-05-16 20:18:11', 'Well, the way they make shows is, they make one show. That show''s called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they''re going to make more shows. Some pilots get picked and become television programs. Some don''t, become nothing. She starred in one of the ones that became nothing.\r\n\r\nDo you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it? Do you see a little Asian child with a blank expression on his face sitting outside on a mechanical helicopter that shakes when you put quarters in it? No? Well, that''s what you see at a toy store. And you must think you''re in a toy store, because you''re here shopping for an infant named Jeb.\r\n', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-05-16 20:18:11', '2013-05-16 20:18:11', '', 6, 'http://masseybrooks.com/2013/05/6-revision-v1/', 0, 'revision', '', 0),
(95, 3, '2013-12-28 16:14:11', '2013-12-28 16:14:11', 'Well, the way they make shows is, they make one show. That show''s called a pilot. Then they show that show to the people who make shows, and on the strength of that one show they decide if they''re going to make more shows. Some pilots get picked and become television programs. Some don''t, become nothing. She starred in one of the ones that became nothing.\r\n\r\nDo you see any Teletubbies in here? Do you see a slender plastic tag clipped to my shirt with my name printed on it? Do you see a little Asian child with a blank expression on his face sitting outside on a mechanical helicopter that shakes when you put quarters in it? No? Well, that''s what you see at a toy store. And you must think you''re in a toy store, because you''re here shopping for an infant named Jeb.', 'About', '', 'inherit', 'open', 'open', '', '6-revision-v1', '', '', '2013-12-28 16:14:11', '2013-12-28 16:14:11', '', 6, 'http://masseybrooks.com/2013/12/6-revision-v1/', 0, 'revision', '', 0),
(96, 3, '2013-12-28 16:20:22', '2013-12-28 16:20:22', '', 'Render_02_BW', '', 'inherit', 'open', 'open', '', 'render_02_bw', '', '', '2013-12-28 16:20:22', '2013-12-28 16:20:22', '', 33, 'http://masseybrooks.com/wp-content/uploads/2013/05/Render_02_BW.png', 0, 'attachment', 'image/png', 0),
(97, 3, '2013-12-28 16:22:21', '2013-12-28 16:22:21', 'Look, just because I don''t be givin'' no man a foot massage don''t make it right for Marsellus to throw Antwone into a glass motherfuckin'' house, fuckin'' up the way the nigger talks. Motherfucker do that shit to me, he better paralyze my ass, ''cause I''ll kill the motherfucker, know what I''m sayin''?', 'Wave Chair', '', 'inherit', 'open', 'open', '', '31-autosave-v1', '', '', '2013-12-28 16:22:21', '2013-12-28 16:22:21', '', 31, 'http://masseybrooks.com/2013/12/31-autosave-v1/', 0, 'revision', '', 0),
(98, 3, '2013-12-28 16:22:22', '2013-12-28 16:22:22', '', 'DSCN2452_BW', '', 'inherit', 'open', 'open', '', 'dscn2452_bw', '', '', '2013-12-28 16:22:22', '2013-12-28 16:22:22', '', 31, 'http://masseybrooks.com/wp-content/uploads/2013/05/DSCN2452_BW.png', 0, 'attachment', 'image/png', 0),
(99, 3, '2013-12-28 16:22:40', '2013-12-28 16:22:40', '', 'DSCN2456_BW', '', 'inherit', 'open', 'open', '', 'dscn2456_bw', '', '', '2013-12-28 16:22:40', '2013-12-28 16:22:40', '', 31, 'http://masseybrooks.com/wp-content/uploads/2013/05/DSCN2456_BW.png', 0, 'attachment', 'image/png', 0),
(100, 3, '2013-12-28 16:23:34', '2013-12-28 16:23:34', '', 'Render_02_BW', '', 'inherit', 'open', 'open', '', 'render_02_bw-2', '', '', '2013-12-28 16:23:34', '2013-12-28 16:23:34', '', 33, 'http://masseybrooks.com/wp-content/uploads/2013/05/Render_02_BW1.png', 0, 'attachment', 'image/png', 0),
(102, 3, '2013-12-28 16:31:42', '2013-12-28 16:31:42', '', 'Untitled', '', 'inherit', 'open', 'open', '', 'untitled', '', '', '2013-12-28 16:31:42', '2013-12-28 16:31:42', '', 29, 'http://masseybrooks.com/wp-content/uploads/2013/05/Morphology.jpg', 0, 'attachment', 'image/jpeg', 0),
(103, 3, '2013-12-28 16:32:54', '2013-12-28 16:32:54', '', 'Untitled', '', 'inherit', 'open', 'open', '', 'untitled-2', '', '', '2013-12-28 16:32:54', '2013-12-28 16:32:54', '', 29, 'http://masseybrooks.com/wp-content/uploads/2013/05/Morphology1.jpg', 0, 'attachment', 'image/jpeg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_terms`
--

DROP TABLE IF EXISTS `mpb_wp_terms`;
CREATE TABLE IF NOT EXISTS `mpb_wp_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mpb_wp_terms`
--

INSERT INTO `mpb_wp_terms` (`term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Uncategorized', 'uncategorized', 0),
(2, 'Menu', 'menu', 0);

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_term_relationships`
--

DROP TABLE IF EXISTS `mpb_wp_term_relationships`;
CREATE TABLE IF NOT EXISTS `mpb_wp_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `mpb_wp_term_relationships`
--

INSERT INTO `mpb_wp_term_relationships` (`object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(8, 2, 0),
(9, 2, 0);

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_term_taxonomy`
--

DROP TABLE IF EXISTS `mpb_wp_term_taxonomy`;
CREATE TABLE IF NOT EXISTS `mpb_wp_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=3 ;

--
-- Dumping data for table `mpb_wp_term_taxonomy`
--

INSERT INTO `mpb_wp_term_taxonomy` (`term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 1),
(2, 2, 'nav_menu', '', 0, 2);

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_usermeta`
--

DROP TABLE IF EXISTS `mpb_wp_usermeta`;
CREATE TABLE IF NOT EXISTS `mpb_wp_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=80 ;

--
-- Dumping data for table `mpb_wp_usermeta`
--

INSERT INTO `mpb_wp_usermeta` (`umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'first_name', ''),
(2, 1, 'last_name', ''),
(3, 1, 'nickname', 'Hillery'),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'true'),
(10, 1, 'mpb_wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'mpb_wp_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'mpb_wp_dashboard_quick_press_last_post_id', '81'),
(15, 1, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(16, 1, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:12:"add-post_tag";i:2;s:15:"add-post_format";}'),
(17, 1, 'nav_menu_recently_edited', '2'),
(18, 1, 'mpb_wp_user-settings', 'editor=tinymce&libraryContent=browse'),
(19, 1, 'mpb_wp_user-settings-time', '1370025824'),
(20, 1, 'closedpostboxes_project', 'a:0:{}'),
(21, 1, 'metaboxhidden_project', 'a:1:{i:0;s:7:"slugdiv";}'),
(22, 2, 'first_name', ''),
(23, 2, 'last_name', ''),
(24, 2, 'nickname', 'drew'),
(25, 2, 'description', ''),
(26, 2, 'rich_editing', 'true'),
(27, 2, 'comment_shortcuts', 'false'),
(28, 2, 'admin_color', 'fresh'),
(29, 2, 'use_ssl', '0'),
(30, 2, 'show_admin_bar_front', 'true'),
(31, 2, 'mpb_wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(32, 2, 'mpb_wp_user_level', '10'),
(33, 2, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media'),
(34, 2, 'mpb_wp_dashboard_quick_press_last_post_id', '104'),
(35, 3, 'first_name', 'Massey'),
(36, 3, 'last_name', 'Brooks'),
(37, 3, 'nickname', 'massey'),
(38, 3, 'description', ''),
(39, 3, 'rich_editing', 'true'),
(40, 3, 'comment_shortcuts', 'false'),
(41, 3, 'admin_color', 'fresh'),
(42, 3, 'use_ssl', '0'),
(43, 3, 'show_admin_bar_front', 'true'),
(44, 3, 'mpb_wp_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(45, 3, 'mpb_wp_user_level', '10'),
(46, 3, 'dismissed_wp_pointers', 'wp330_toolbar,wp330_saving_widgets,wp340_choose_image_from_library,wp340_customize_current_theme_link,wp350_media,wp360_revisions'),
(47, 3, 'mpb_wp_dashboard_quick_press_last_post_id', '104'),
(48, 3, 'nav_menu_recently_edited', '2'),
(49, 3, 'managenav-menuscolumnshidden', 'a:4:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";}'),
(50, 3, 'metaboxhidden_nav-menus', 'a:3:{i:0;s:8:"add-post";i:1;s:11:"add-project";i:2;s:12:"add-post_tag";}'),
(51, 3, 'wpseo_title', ''),
(52, 3, 'wpseo_metadesc', ''),
(53, 3, 'wpseo_metakey', ''),
(54, 3, 'aim', ''),
(55, 3, 'yim', ''),
(56, 3, 'jabber', ''),
(57, 3, 'googleplus', ''),
(58, 3, 'twitter', ''),
(59, 3, 'mpb_wp_user-settings', 'libraryContent=browse&editor=tinymce'),
(60, 3, 'mpb_wp_user-settings-time', '1388248374'),
(61, 3, 'closedpostboxes_project', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(62, 3, 'metaboxhidden_project', 'a:2:{i:0;s:6:"acf_92";i:1;s:7:"slugdiv";}'),
(63, 2, '_yoast_wpseo_profile_updated', '1388248094'),
(64, 1, '_yoast_wpseo_profile_updated', '1388244815'),
(65, 3, '_yoast_wpseo_profile_updated', '1388244815'),
(66, 3, 'meta-box-order_page', 'a:4:{s:15:"acf_after_title";s:0:"";s:4:"side";s:36:"submitdiv,pageparentdiv,postimagediv";s:6:"normal";s:95:"acf_92,acf_55,revisionsdiv,wpseo_meta,postcustom,commentstatusdiv,commentsdiv,slugdiv,authordiv";s:8:"advanced";s:0:"";}'),
(67, 3, 'screen_layout_page', '2'),
(68, 3, 'closedpostboxes_page', 'a:1:{i:0;s:10:"wpseo_meta";}'),
(69, 3, 'metaboxhidden_page', 'a:7:{i:0;s:6:"acf_55";i:1;s:12:"revisionsdiv";i:2;s:10:"postcustom";i:3;s:16:"commentstatusdiv";i:4;s:11:"commentsdiv";i:5;s:7:"slugdiv";i:6;s:9:"authordiv";}'),
(70, 2, 'wpseo_title', ''),
(71, 2, 'wpseo_metadesc', ''),
(72, 2, 'wpseo_metakey', ''),
(73, 2, 'aim', ''),
(74, 2, 'yim', ''),
(75, 2, 'jabber', ''),
(76, 2, 'googleplus', ''),
(77, 2, 'twitter', ''),
(78, 2, 'facebook', ''),
(79, 2, 'default_password_nag', '');

-- --------------------------------------------------------

--
-- Table structure for table `mpb_wp_users`
--

DROP TABLE IF EXISTS `mpb_wp_users`;
CREATE TABLE IF NOT EXISTS `mpb_wp_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci AUTO_INCREMENT=4 ;

--
-- Dumping data for table `mpb_wp_users`
--

INSERT INTO `mpb_wp_users` (`ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Hillery', '$P$BXggvg24cyhK0TbSinEjwB.Mdj4RQt/', 'hillery', 'brookshillery@gmail.com', '', '2013-05-07 17:04:01', '', 0, 'Hillery'),
(2, 'drew', '$P$BDpwcw63D/.xiBs19BX7Bw9xTPQkQW/', 'drew', 'drew@dangodesign.net', '', '2013-06-05 19:01:19', '', 0, 'drew'),
(3, 'masseybrooks', '$P$BiuIHeRWwgOnJZsp9/mj21Q/qSgWpN0', 'massey', 'masseybrooks@gmail.com', '', '2013-12-28 15:11:36', '', 0, 'Massey Brooks');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
